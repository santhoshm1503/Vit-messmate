import React, { useEffect, useMemo, useState } from 'react';
import {
  AppSettings,
  BillingCycle,
  FoodPreset,
  MEAL_CATEGORIES,
  MealCategory,
  MealTransaction,
} from './types/mess';
import {
  calculateCycleMetrics,
  formatCredits,
  generateSmartInsights,
  roundCredits,
  toLocalDateString,
  toLocalTimeString,
} from './utils/calculations';
import {
  createDefaultCycleAndSeedData,
  loadInitialDataFromDB,
  saveAllDataToDB,
} from './db/indexedDb';
import { DashboardView } from './components/DashboardView';
import { AddMealView } from './components/AddMealView';
import { HistoryView } from './components/HistoryView';
import { AnalyticsView } from './components/AnalyticsView';
import { SettingsView } from './components/SettingsView';
import { EditMealModal } from './components/EditMealModal';
import { OfflineIndicator, PWAInstallButton } from './components/PWAInstallPrompt';
import {
  BarChart3,
  Clock,
  Home,
  PlusCircle,
  RotateCcw,
  Settings,
} from 'lucide-react';

type ActiveTab = 'home' | 'add' | 'history' | 'analytics' | 'settings';

export default function App() {
  const initialSeed = useMemo(() => createDefaultCycleAndSeedData(), []);
  const [cycles, setCycles] = useState<BillingCycle[]>(initialSeed.cycles);
  const [transactions, setTransactions] = useState<MealTransaction[]>(initialSeed.transactions);
  const [settings, setSettings] = useState<AppSettings>(initialSeed.settings);
  const [presets, setPresets] = useState<FoodPreset[]>(initialSeed.presets);
  const [isHydrated, setIsHydrated] = useState(false);

  const [activeTab, setActiveTab] = useState<ActiveTab>(() => {
    if (typeof window !== 'undefined') {
      const param = new URLSearchParams(window.location.search).get('tab');
      if (
        param === 'home' ||
        param === 'add' ||
        param === 'history' ||
        param === 'analytics' ||
        param === 'settings'
      ) {
        return param;
      }
    }
    return 'home';
  });
  const [prefillAddDate, setPrefillAddDate] = useState<string | undefined>(undefined);
  const [editingTransaction, setEditingTransaction] = useState<MealTransaction | null>(null);
  const [recentlyDeleted, setRecentlyDeleted] = useState<MealTransaction | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Load persisted data from IndexedDB on mount
  useEffect(() => {
    let mounted = true;
    loadInitialDataFromDB().then((data) => {
      if (!mounted) return;
      setCycles(data.cycles);
      setTransactions(data.transactions);
      setSettings(data.settings);
      setPresets(data.presets);
      setIsHydrated(true);
    });
    return () => {
      mounted = false;
    };
  }, []);

  // Sync theme class on <html>
  useEffect(() => {
    const root = document.documentElement;
    if (settings.theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [settings.theme]);

  // Persist to IndexedDB whenever state mutates after initial hydration
  useEffect(() => {
    if (!isHydrated) return;
    saveAllDataToDB(cycles, transactions, settings, presets);
  }, [cycles, transactions, settings, presets, isHydrated]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((curr) => (curr === msg ? null : curr));
    }, 3500);
  };

  const activeCycle = useMemo(() => {
    return (
      cycles.find((c) => c.id === settings.activeCycleId) ||
      cycles.find((c) => !c.isArchived) ||
      cycles[0]
    );
  }, [cycles, settings.activeCycleId]);

  const cycleMetrics = useMemo(
    () => calculateCycleMetrics(activeCycle, transactions, toLocalDateString()),
    [activeCycle, transactions]
  );

  const smartInsights = useMemo(
    () =>
      generateSmartInsights(
        activeCycle,
        cycleMetrics,
        transactions,
        toLocalDateString()
      ),
    [activeCycle, cycleMetrics, transactions]
  );

  const lastRecordedMeal = useMemo(() => {
    const cycleTx = transactions
      .filter((t) => t.cycleId === activeCycle.id)
      .sort(
        (a, b) =>
          b.date.localeCompare(a.date) ||
          b.time.localeCompare(a.time) ||
          b.createdAt - a.createdAt
      );
    return cycleTx[0];
  }, [transactions, activeCycle.id]);

  // Handlers
  const handleAddMeals = (
    newMeals: Array<{
      category: MealCategory;
      foodName: string;
      credits: number;
      unitCredits: number;
      quantity: number;
      date: string;
      time: string;
      notes?: string;
      tags?: string[];
    }>
  ) => {
    const now = Date.now();
    const created: MealTransaction[] = newMeals.map((m, idx) => ({
      id: `tx-${now}-${idx}-${Math.random().toString(36).slice(2, 7)}`,
      cycleId: activeCycle.id,
      category: m.category,
      foodName: m.foodName,
      credits: roundCredits(m.credits),
      unitCredits: roundCredits(m.unitCredits),
      quantity: m.quantity,
      date: m.date,
      time: m.time,
      notes: m.notes,
      tags: m.tags,
      createdAt: now + idx,
      updatedAt: now + idx,
    }));

    setTransactions((prev) => [...created, ...prev]);
    const totalAdded = roundCredits(created.reduce((s, t) => s + t.credits, 0));
    showToast(
      `Recorded ${created.length} meal${created.length === 1 ? '' : 's'} (${formatCredits(
        totalAdded,
        settings.creditDisplayFormat
      )} cr). Balance updated.`
    );
    setActiveTab('home');
  };

  const handleQuickAddMeal = (preset: {
    foodName: string;
    category: MealCategory;
    credits: number;
    date?: string;
    tags?: string[];
  }) => {
    const now = Date.now();
    const entry: MealTransaction = {
      id: `tx-${now}-${Math.random().toString(36).slice(2, 7)}`,
      cycleId: activeCycle.id,
      category: preset.category,
      foodName: preset.foodName,
      credits: roundCredits(preset.credits),
      unitCredits: roundCredits(preset.credits),
      quantity: 1,
      date: preset.date || toLocalDateString(),
      time: toLocalTimeString(),
      tags: preset.tags,
      createdAt: now,
      updatedAt: now,
    };
    setTransactions((prev) => [entry, ...prev]);
    showToast(
      `Quick-added "${entry.foodName}" (${formatCredits(
        entry.credits,
        settings.creditDisplayFormat
      )} cr).`
    );
  };

  const handleDuplicateTransaction = (tx: MealTransaction) => {
    const now = Date.now();
    const copy: MealTransaction = {
      ...tx,
      id: `tx-${now}-${Math.random().toString(36).slice(2, 7)}`,
      cycleId: activeCycle.id,
      date: toLocalDateString(),
      time: toLocalTimeString(),
      createdAt: now,
      updatedAt: now,
    };
    setTransactions((prev) => [copy, ...prev]);
    showToast(
      `Duplicated "${copy.foodName}" (${formatCredits(
        copy.credits,
        settings.creditDisplayFormat
      )} cr) for today.`
    );
  };

  const handleDuplicateLastMeal = () => {
    if (!lastRecordedMeal) return;
    handleDuplicateTransaction(lastRecordedMeal);
  };

  const handleSaveEditedTransaction = (updated: MealTransaction) => {
    setTransactions((prev) => prev.map((t) => (t.id === updated.id ? updated : t)));
    setEditingTransaction(null);
    showToast(
      `Updated "${updated.foodName}" (${formatCredits(
        updated.credits,
        settings.creditDisplayFormat
      )} cr).`
    );
  };

  const handleDeleteTransaction = (id: string) => {
    const target = transactions.find((t) => t.id === id);
    if (!target) return;
    setRecentlyDeleted(target);
    setTransactions((prev) => prev.filter((t) => t.id !== id));
  };

  const handleUndoDelete = () => {
    if (!recentlyDeleted) return;
    setTransactions((prev) => [recentlyDeleted, ...prev]);
    showToast(`Restored "${recentlyDeleted.foodName}".`);
    setRecentlyDeleted(null);
  };

  const handleAddPreset = (preset: Omit<FoodPreset, 'id'>) => {
    const newPreset: FoodPreset = {
      ...preset,
      id: `preset-custom-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    };
    setPresets((prev) => [newPreset, ...prev]);
  };

  const handleDeletePreset = (id: string) => {
    setPresets((prev) => prev.filter((p) => p.id !== id));
  };

  const handleUpdateCycle = (updatedCycle: BillingCycle) => {
    setCycles((prev) => prev.map((c) => (c.id === updatedCycle.id ? updatedCycle : c)));
  };

  const handleStartNewCycle = (params: {
    name: string;
    dailyReference: number;
    cycleDuration: number;
    monthlyBudget: number;
    startDate: string;
    endDate: string;
  }) => {
    const newCycleId = `cycle-${Date.now()}`;
    const newCycle: BillingCycle = {
      id: newCycleId,
      name: params.name,
      dailyReference: roundCredits(params.dailyReference),
      cycleDuration: params.cycleDuration,
      monthlyBudget: roundCredits(params.monthlyBudget),
      startDate: params.startDate,
      endDate: params.endDate,
      isArchived: false,
      createdAt: Date.now(),
    };

    // Archive existing active cycle without deleting any historical transactions
    setCycles((prev) => [
      newCycle,
      ...prev.map((c) => (c.id === activeCycle.id ? { ...c, isArchived: true } : c)),
    ]);
    setSettings((prev) => ({
      ...prev,
      activeCycleId: newCycleId,
    }));
  };

  const handleSwitchActiveCycle = (cycleId: string) => {
    setSettings((prev) => ({
      ...prev,
      activeCycleId: cycleId,
    }));
    showToast('Switched active billing cycle.');
  };

  const handleResetCurrentCycleTransactions = () => {
    setTransactions((prev) => prev.filter((t) => t.cycleId !== activeCycle.id));
  };

  const handleUpdateSettings = (patch: Partial<AppSettings>) => {
    setSettings((prev) => ({ ...prev, ...patch }));
  };

  // Export CSV
  const handleExportCSV = () => {
    const cycleTx = transactions.filter((t) => t.cycleId === activeCycle.id);
    const headers = [
      'ID',
      'Date',
      'Time',
      'Category',
      'Food Item',
      'Quantity',
      'Credits',
      'Notes',
      'Tags',
    ];
    const rows = cycleTx.map((t) => [
      t.id,
      t.date,
      t.time,
      t.category,
      `"${t.foodName.replace(/"/g, '""')}"`,
      t.quantity,
      t.credits,
      `"${(t.notes || '').replace(/"/g, '""')}"`,
      `"${(t.tags || []).join('; ')}"`,
    ]);
    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `vit-messmate-${activeCycle.startDate}-to-${activeCycle.endDate}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Exported cycle transactions to CSV.');
  };

  // Export Monthly Report
  const handleExportMonthlyReport = () => {
    const cycleTx = transactions.filter((t) => t.cycleId === activeCycle.id);
    const catLines = MEAL_CATEGORIES.map((cat) => {
      const sum = roundCredits(
        cycleTx.filter((t) => t.category === cat).reduce((s, t) => s + t.credits, 0)
      );
      return `  - ${cat}: ${formatCredits(sum, settings.creditDisplayFormat)} credits`;
    }).join('\n');

    const report = [
      `VIT MESSMATE — MONTHLY MESS CREDIT REPORT`,
      `Tagline: Eat Smart. Track Credits. Stay Balanced.`,
      `==================================================`,
      `Cycle: ${activeCycle.name}`,
      `Period: ${activeCycle.startDate} to ${activeCycle.endDate} (${activeCycle.cycleDuration} days)`,
      `Monthly Budget: ${formatCredits(cycleMetrics.monthlyBudget)} credits`,
      `Daily Reference: ${formatCredits(cycleMetrics.dailyReference)} credits/day`,
      ``,
      `SUMMARY METRICS:`,
      `  - Total Credits Consumed: ${formatCredits(cycleMetrics.totalUsed)} credits (${cycleMetrics.percentageUsed}%)`,
      `  - Remaining Credits: ${formatCredits(cycleMetrics.remainingCredits)} credits`,
      `  - Days Elapsed: ${cycleMetrics.daysElapsed} | Days Remaining: ${cycleMetrics.daysRemaining}`,
      `  - Recommended Daily Allowance: ${formatCredits(cycleMetrics.recommendedDailyAllowance)} credits/day`,
      `  - Total Recorded Meals: ${cycleTx.length}`,
      ``,
      `CATEGORY BREAKDOWN:`,
      catLines,
      ``,
      `SMART INSIGHTS:`,
      ...smartInsights.map((i) => `  * ${i.title}: ${i.description}`),
    ].join('\n');

    const blob = new Blob([report], { type: 'text/plain;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `vit-messmate-report-${activeCycle.startDate}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Downloaded monthly expenditure report.');
  };

  // Download JSON Backup
  const handleDownloadJSONBackup = () => {
    const payload = {
      app: 'VIT MessMate',
      exportedAt: new Date().toISOString(),
      cycles,
      transactions,
      settings,
      presets,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `vit-messmate-backup-${toLocalDateString()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Downloaded full JSON backup.');
  };

  const handleRestoreJSONBackup = (data: {
    cycles: BillingCycle[];
    transactions: MealTransaction[];
    settings: AppSettings;
    presets?: FoodPreset[];
  }) => {
    setCycles(data.cycles);
    setTransactions(data.transactions);
    if (data.settings) setSettings(data.settings);
    if (data.presets && data.presets.length > 0) setPresets(data.presets);
  };

  const navItems: Array<{
    id: ActiveTab;
    label: string;
    icon: React.FC<{ className?: string }>;
  }> = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'add', label: 'Add Meal', icon: PlusCircle },
    { id: 'history', label: 'History', icon: Clock },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-[#0B1120] text-slate-900 dark:text-slate-100">
      <OfflineIndicator />

      {/* Strict 3-Zone Top Bar Contract */}
      <header className="sticky top-0 z-30 flex items-center justify-between gap-8 px-4 sm:px-6 h-14 border-b border-slate-200 dark:border-slate-800/90 bg-white/95 dark:bg-[#0B1120]/95 backdrop-blur-md">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="#home"
          onClick={(e) => {
            e.preventDefault();
            setActiveTab('home');
          }}
          className="text-base sm:text-lg font-extrabold tracking-tight text-slate-900 dark:text-white whitespace-nowrap shrink-0 font-display"
        >
          VIT MessMate
        </a>

        {/* Zone 2: 5 concise single-line text navigation links */}
        <nav
          aria-label="Top navigation"
          className="hidden md:flex items-center gap-6 text-xs font-semibold text-slate-600 dark:text-slate-400"
        >
          {navItems.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                if (item.id === 'add') setPrefillAddDate(undefined);
                setActiveTab(item.id);
              }}
              className={`hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer py-1 ${
                activeTab === item.id
                  ? 'text-emerald-600 dark:text-emerald-400 underline underline-offset-8 decoration-2'
                  : ''
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={() => {
              setPrefillAddDate(undefined);
              setActiveTab('add');
            }}
            className="px-3.5 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Add Meal
          </button>
        </div>
      </header>

      {/* Main Workspace Container: Desktop Sidebar + Main Viewport */}
      <div className="flex-1 flex max-w-[1440px] w-full mx-auto">
        {/* Desktop Sidebar */}
        <aside
          aria-label="Desktop sidebar navigation"
          className="hidden lg:flex w-64 shrink-0 flex-col justify-between border-r border-slate-200 dark:border-slate-800/90 bg-white/50 dark:bg-[#0D1527] p-5"
        >
          <div className="space-y-6">
            <div>
              <p className="text-xs font-medium text-emerald-600 dark:text-emerald-400">
                Eat Smart. Track Credits. Stay Balanced.
              </p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                VIT Paid-Mess Credit & Allowance Manager
              </p>
            </div>

            <nav aria-label="Sidebar links" className="space-y-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      if (item.id === 'add') setPrefillAddDate(undefined);
                      setActiveTab(item.id);
                    }}
                    className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                      isActive
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/70 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>

            {/* Quick Sidebar Credit Ledger Summary */}
            <div className="pt-5 border-t border-slate-200 dark:border-slate-800 space-y-3 font-mono tabular-nums">
              <div>
                <span className="text-[11px] font-sans text-slate-500 dark:text-slate-400 block">
                  Remaining Balance
                </span>
                <span className="text-lg font-bold text-slate-900 dark:text-white">
                  {formatCredits(cycleMetrics.remainingCredits, settings.creditDisplayFormat)} cr
                </span>
              </div>
              <div>
                <span className="text-[11px] font-sans text-slate-500 dark:text-slate-400 block">
                  Daily Allowance ({cycleMetrics.daysRemaining}d left)
                </span>
                <span className="text-sm font-bold text-emerald-600 dark:text-emerald-400">
                  {formatCredits(
                    cycleMetrics.recommendedDailyAllowance,
                    settings.creditDisplayFormat
                  )}{' '}
                  cr/day
                </span>
              </div>
              <div>
                <span className="text-[11px] font-sans text-slate-500 dark:text-slate-400 block">
                  Used / Monthly Budget
                </span>
                <span className="text-xs text-slate-700 dark:text-slate-300">
                  {formatCredits(cycleMetrics.totalUsed, settings.creditDisplayFormat)} /{' '}
                  {formatCredits(cycleMetrics.monthlyBudget, settings.creditDisplayFormat)} cr
                </span>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-2.5">
            <PWAInstallButton variant="card" />
            <div className="text-[11px] text-slate-500 dark:text-slate-400">
              Offline PWA & IndexedDB persistence active
            </div>
          </div>
        </aside>

        {/* Main Content Viewport */}
        <main className="flex-1 min-w-0 px-4 sm:px-6 lg:px-8 py-6 pb-24 lg:pb-10">
          {/* Global Status / Undo Toast */}
          {(toastMessage || (recentlyDeleted && activeTab !== 'history')) && (
            <div
              role="status"
              className="mb-5 rounded-xl border border-emerald-500/40 bg-emerald-950/90 text-white px-4 py-2.5 flex items-center justify-between gap-3 shadow-md text-xs"
            >
              <span>
                {recentlyDeleted
                  ? `Deleted "${recentlyDeleted.foodName}" (${formatCredits(
                      recentlyDeleted.credits,
                      settings.creditDisplayFormat
                    )} cr restored).`
                  : toastMessage}
              </span>
              {recentlyDeleted && (
                <button
                  type="button"
                  onClick={handleUndoDelete}
                  className="inline-flex items-center gap-1 rounded-lg bg-emerald-500 hover:bg-emerald-400 px-2.5 py-1 text-xs font-bold text-slate-950 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Undo Delete</span>
                </button>
              )}
            </div>
          )}

          {activeTab === 'home' && (
            <DashboardView
              cycle={activeCycle}
              metrics={cycleMetrics}
              transactions={transactions}
              presets={presets}
              insights={smartInsights}
              creditFormat={settings.creditDisplayFormat}
              lowBalanceThreshold={settings.lowBalanceAlertThreshold}
              overspendingAlertEnabled={settings.overspendingAlertEnabled}
              onQuickAddMeal={handleQuickAddMeal}
              onDuplicateLastMeal={handleDuplicateLastMeal}
              onNavigateToAdd={(dateStr) => {
                setPrefillAddDate(dateStr);
                setActiveTab('add');
              }}
              onEditTransaction={(tx) => setEditingTransaction(tx)}
              onDeleteTransaction={handleDeleteTransaction}
            />
          )}

          {activeTab === 'add' && (
            <AddMealView
              prefillDate={prefillAddDate}
              presets={presets}
              lastMeal={lastRecordedMeal}
              creditFormat={settings.creditDisplayFormat}
              onAddMeals={handleAddMeals}
              onAddPreset={handleAddPreset}
              onDeletePreset={handleDeletePreset}
              onDuplicateLastMeal={handleDuplicateLastMeal}
            />
          )}

          {activeTab === 'history' && (
            <HistoryView
              cycles={cycles}
              activeCycleId={activeCycle.id}
              transactions={transactions}
              creditFormat={settings.creditDisplayFormat}
              recentlyDeleted={recentlyDeleted}
              onEditTransaction={(tx) => setEditingTransaction(tx)}
              onDeleteTransaction={handleDeleteTransaction}
              onUndoDelete={handleUndoDelete}
              onDuplicateTransaction={handleDuplicateTransaction}
              onExportCSV={handleExportCSV}
            />
          )}

          {activeTab === 'analytics' && (
            <AnalyticsView
              cycle={activeCycle}
              metrics={cycleMetrics}
              transactions={transactions}
              insights={smartInsights}
              creditFormat={settings.creditDisplayFormat}
              onExportMonthlyReport={handleExportMonthlyReport}
            />
          )}

          {activeTab === 'settings' && (
            <SettingsView
              cycle={activeCycle}
              cycles={cycles}
              transactions={transactions}
              settings={settings}
              presets={presets}
              onUpdateCycle={handleUpdateCycle}
              onStartNewCycle={handleStartNewCycle}
              onSwitchActiveCycle={handleSwitchActiveCycle}
              onResetCurrentCycleTransactions={handleResetCurrentCycleTransactions}
              onUpdateSettings={handleUpdateSettings}
              onExportCSV={handleExportCSV}
              onExportMonthlyReport={handleExportMonthlyReport}
              onDownloadJSONBackup={handleDownloadJSONBackup}
              onRestoreJSONBackup={handleRestoreJSONBackup}
            />
          )}
        </main>
      </div>

      {/* Edit Meal Modal */}
      {editingTransaction && (
        <EditMealModal
          transaction={editingTransaction}
          onClose={() => setEditingTransaction(null)}
          onSave={handleSaveEditedTransaction}
        />
      )}

      {/* Mobile Bottom Navigation Bar (1. Home, 2. Add Meal, 3. History, 4. Analytics, 5. Settings) */}
      <nav
        aria-label="Mobile bottom navigation"
        className="lg:hidden fixed bottom-0 left-0 right-0 z-40 h-16 bg-white/95 dark:bg-[#0B1120]/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 grid grid-cols-5 items-center"
      >
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                if (item.id === 'add') setPrefillAddDate(undefined);
                setActiveTab(item.id);
              }}
              className={`min-h-[44px] min-w-[44px] flex flex-col items-center justify-center transition-colors cursor-pointer ${
                isActive
                  ? 'text-emerald-600 dark:text-emerald-400 font-bold'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-[10px] font-medium tracking-tight mt-1 whitespace-nowrap">
                {item.label}
              </span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}
