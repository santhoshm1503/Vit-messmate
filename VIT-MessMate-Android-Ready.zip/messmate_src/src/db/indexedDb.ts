import {
  AppSettings,
  BillingCycle,
  FoodPreset,
  MealTransaction,
} from '../types/mess';
import {
  addDaysToDateString,
  calculateCycleEndDate,
  toLocalDateString,
} from '../utils/calculations';

const DB_NAME = 'vit_messmate_db';
const DB_VERSION = 1;

const STORE_CYCLES = 'cycles';
const STORE_TRANSACTIONS = 'transactions';
const STORE_PRESETS = 'presets';
const STORE_SETTINGS = 'settings';

export const DEFAULT_PRESETS: FoodPreset[] = [
  { id: 'preset-bf-standard', foodName: 'Masala Dosa & Coffee', category: 'Breakfast', credits: 75, tags: ['South Indian', 'Morning'] },
  { id: 'preset-lunch-thali', foodName: 'Special Executive Lunch', category: 'Lunch', credits: 110, tags: ['Thali', 'Full Meal'] },
  { id: 'preset-snacks-samosa', foodName: 'Samosa & Ginger Chai', category: 'Snacks', credits: 40, tags: ['Evening', 'Hot'] },
  { id: 'preset-dinner-combo', foodName: 'Paneer Butter Masala & Rotis', category: 'Dinner', credits: 120, tags: ['North Indian', 'Dinner'] },
  { id: 'preset-bf-idli', foodName: 'Idli Vada Sambar', category: 'Breakfast', credits: 60, tags: ['Light', 'South Indian'] },
  { id: 'preset-lunch-mini', foodName: 'Mini Meals & Buttermilk', category: 'Lunch', credits: 85, tags: ['Quick Lunch'] },
  { id: 'preset-dinner-biryani', foodName: 'Special Veg / Chicken Biryani', category: 'Dinner', credits: 135, tags: ['Special'] },
  { id: 'preset-bev-juice', foodName: 'Fresh Watermelon Juice', category: 'Beverages', credits: 35, tags: ['Refreshment'] },
];

export function createDefaultCycleAndSeedData(todayStr: string = toLocalDateString()): {
  cycles: BillingCycle[];
  transactions: MealTransaction[];
  settings: AppSettings;
  presets: FoodPreset[];
} {
  // Start cycle 3 days ago so 3 days have elapsed and 27 days remain in the 30-day cycle
  const startDate = addDaysToDateString(todayStr, -3);
  const endDate = calculateCycleEndDate(startDate, 30);
  const activeCycleId = 'cycle-current';
  const prevCycleId = 'cycle-prev-archived';

  const prevStartDate = addDaysToDateString(startDate, -30);
  const prevEndDate = calculateCycleEndDate(prevStartDate, 30);

  const activeCycle: BillingCycle = {
    id: activeCycleId,
    name: `Active Cycle (${startDate} to ${endDate})`,
    dailyReference: 288,
    cycleDuration: 30,
    monthlyBudget: 8640,
    startDate,
    endDate,
    isArchived: false,
    createdAt: Date.now() - 3 * 86400000,
  };

  const archivedCycle: BillingCycle = {
    id: prevCycleId,
    name: `Previous Cycle (${prevStartDate} to ${prevEndDate})`,
    dailyReference: 288,
    cycleDuration: 30,
    monthlyBudget: 8640,
    startDate: prevStartDate,
    endDate: prevEndDate,
    isArchived: true,
    createdAt: Date.now() - 33 * 86400000,
  };

  const day1 = addDaysToDateString(todayStr, -3);
  const day2 = addDaysToDateString(todayStr, -2);
  const day3 = addDaysToDateString(todayStr, -1);

  // Day 1 = 350 credits (85 + 125 + 140)
  // Day 2 = 250 credits (60 + 95 + 95)
  // Day 3 = 300 credits (70 + 110 + 35 + 85)
  // Total = 900 credits used, 7,740 remaining, 27 days remaining -> 286.67 cr/day allowance
  const baseTime = Date.now() - 3 * 86400000;
  const transactions: MealTransaction[] = [
    {
      id: 'tx-seed-1',
      cycleId: activeCycleId,
      category: 'Breakfast',
      foodName: 'Ghee Roast Masala Dosa & Filter Coffee',
      credits: 85,
      unitCredits: 85,
      quantity: 1,
      date: day1,
      time: '08:15',
      notes: 'Crispy roast at Darling Mess counter',
      tags: ['South Indian', 'Breakfast'],
      createdAt: baseTime + 1000,
      updatedAt: baseTime + 1000,
    },
    {
      id: 'tx-seed-2',
      cycleId: activeCycleId,
      category: 'Lunch',
      foodName: 'Special Executive North Indian Thali',
      credits: 125,
      unitCredits: 125,
      quantity: 1,
      date: day1,
      time: '12:45',
      notes: 'Includes Dal Makhani, Paneer, 3 Phulkas & Gulab Jamun',
      tags: ['Thali', 'North Indian'],
      createdAt: baseTime + 2000,
      updatedAt: baseTime + 2000,
    },
    {
      id: 'tx-seed-3',
      cycleId: activeCycleId,
      category: 'Dinner',
      foodName: 'Paneer Butter Masala & Garlic Naan Combo',
      credits: 140,
      unitCredits: 140,
      quantity: 1,
      date: day1,
      time: '20:10',
      notes: 'Post-lab dinner with friends',
      tags: ['Combo', 'Dinner'],
      createdAt: baseTime + 3000,
      updatedAt: baseTime + 3000,
    },
    {
      id: 'tx-seed-4',
      cycleId: activeCycleId,
      category: 'Breakfast',
      foodName: 'Idli Vada Sambar & Chutney',
      credits: 60,
      unitCredits: 60,
      quantity: 1,
      date: day2,
      time: '08:30',
      tags: ['Light', 'Morning'],
      createdAt: baseTime + 86400000 + 1000,
      updatedAt: baseTime + 86400000 + 1000,
    },
    {
      id: 'tx-seed-5',
      cycleId: activeCycleId,
      category: 'Lunch',
      foodName: 'South Indian Mini Meals & Curd',
      credits: 95,
      unitCredits: 95,
      quantity: 1,
      date: day2,
      time: '13:10',
      tags: ['South Indian'],
      createdAt: baseTime + 86400000 + 2000,
      updatedAt: baseTime + 86400000 + 2000,
    },
    {
      id: 'tx-seed-6',
      cycleId: activeCycleId,
      category: 'Dinner',
      foodName: 'Schezwan Veg Fried Rice & Gobi Manchurian',
      credits: 95,
      unitCredits: 95,
      quantity: 1,
      date: day2,
      time: '19:50',
      tags: ['Chinese', 'Dinner'],
      createdAt: baseTime + 86400000 + 3000,
      updatedAt: baseTime + 86400000 + 3000,
    },
    {
      id: 'tx-seed-7',
      cycleId: activeCycleId,
      category: 'Breakfast',
      foodName: 'Onion Podi Uttapam',
      credits: 70,
      unitCredits: 70,
      quantity: 1,
      date: day3,
      time: '08:20',
      tags: ['South Indian'],
      createdAt: baseTime + 172800000 + 1000,
      updatedAt: baseTime + 172800000 + 1000,
    },
    {
      id: 'tx-seed-8',
      cycleId: activeCycleId,
      category: 'Lunch',
      foodName: 'Rajma Chawal Bowl & Sweet Lassi',
      credits: 110,
      unitCredits: 110,
      quantity: 1,
      date: day3,
      time: '13:00',
      tags: ['North Indian', 'Combo'],
      createdAt: baseTime + 172800000 + 2000,
      updatedAt: baseTime + 172800000 + 2000,
    },
    {
      id: 'tx-seed-9',
      cycleId: activeCycleId,
      category: 'Snacks',
      foodName: 'Punjabi Samosa (2 pcs) & Masala Chai',
      credits: 35,
      unitCredits: 35,
      quantity: 1,
      date: day3,
      time: '17:15',
      tags: ['Evening Snack'],
      createdAt: baseTime + 172800000 + 3000,
      updatedAt: baseTime + 172800000 + 3000,
    },
    {
      id: 'tx-seed-10',
      cycleId: activeCycleId,
      category: 'Dinner',
      foodName: 'Hyderabadi Veg Dum Biryani & Raita',
      credits: 85,
      unitCredits: 85,
      quantity: 1,
      date: day3,
      time: '20:15',
      tags: ['Biryani', 'Dinner'],
      createdAt: baseTime + 172800000 + 4000,
      updatedAt: baseTime + 172800000 + 4000,
    },
    // Historical previous cycle entries to demonstrate multi-cycle history
    {
      id: 'tx-prev-1',
      cycleId: prevCycleId,
      category: 'Lunch',
      foodName: 'Previous Cycle Special Thali',
      credits: 120,
      unitCredits: 120,
      quantity: 1,
      date: addDaysToDateString(prevStartDate, 5),
      time: '13:00',
      notes: 'Archived billing cycle entry',
      tags: ['Archived'],
      createdAt: baseTime - 20 * 86400000,
      updatedAt: baseTime - 20 * 86400000,
    },
    {
      id: 'tx-prev-2',
      cycleId: prevCycleId,
      category: 'Dinner',
      foodName: 'Chole Bhature & Badam Milk',
      credits: 130,
      unitCredits: 130,
      quantity: 1,
      date: addDaysToDateString(prevStartDate, 12),
      time: '20:00',
      notes: 'Archived billing cycle entry',
      tags: ['Archived'],
      createdAt: baseTime - 15 * 86400000,
      updatedAt: baseTime - 15 * 86400000,
    },
  ];

  const settings: AppSettings = {
    theme: 'dark',
    creditDisplayFormat: 'integer-preferred',
    creditSymbol: 'cr',
    dailyReminderEnabled: true,
    dailyReminderTime: '21:00',
    overspendingAlertEnabled: true,
    lowBalanceAlertThreshold: 1200,
    activeCycleId,
  };

  return {
    cycles: [activeCycle, archivedCycle],
    transactions,
    settings,
    presets: DEFAULT_PRESETS,
  };
}

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB is not supported in this environment'));
      return;
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_CYCLES)) {
        db.createObjectStore(STORE_CYCLES, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_TRANSACTIONS)) {
        const txStore = db.createObjectStore(STORE_TRANSACTIONS, { keyPath: 'id' });
        txStore.createIndex('cycleId', 'cycleId', { unique: false });
        txStore.createIndex('date', 'date', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORE_PRESETS)) {
        db.createObjectStore(STORE_PRESETS, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_SETTINGS)) {
        db.createObjectStore(STORE_SETTINGS, { keyPath: 'id' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function getAllFromStore<T>(db: IDBDatabase, storeName: string): Promise<T[]> {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result as T[]);
    req.onerror = () => reject(req.error);
  });
}

export async function loadInitialDataFromDB(): Promise<{
  cycles: BillingCycle[];
  transactions: MealTransaction[];
  settings: AppSettings;
  presets: FoodPreset[];
}> {
  try {
    const db = await openDatabase();
    const [cycles, transactions, presets, settingsRows] = await Promise.all([
      getAllFromStore<BillingCycle>(db, STORE_CYCLES),
      getAllFromStore<MealTransaction>(db, STORE_TRANSACTIONS),
      getAllFromStore<FoodPreset>(db, STORE_PRESETS),
      getAllFromStore<{ id: string; value: AppSettings }>(db, STORE_SETTINGS),
    ]);

    if (cycles.length === 0) {
      const seed = createDefaultCycleAndSeedData();
      await saveAllDataToDB(seed.cycles, seed.transactions, seed.settings, seed.presets);
      db.close();
      return seed;
    }

    const storedSettings = settingsRows.find((r) => r.id === 'app_settings')?.value;
    const fallbackSeed = createDefaultCycleAndSeedData();
    const activeCycleExists =
      storedSettings && cycles.some((c) => c.id === storedSettings.activeCycleId);

    const finalSettings: AppSettings = storedSettings
      ? {
          ...fallbackSeed.settings,
          ...storedSettings,
          activeCycleId: activeCycleExists
            ? storedSettings.activeCycleId
            : cycles.find((c) => !c.isArchived)?.id || cycles[0].id,
        }
      : {
          ...fallbackSeed.settings,
          activeCycleId: cycles.find((c) => !c.isArchived)?.id || cycles[0].id,
        };

    db.close();
    return {
      cycles: cycles.sort((a, b) => b.createdAt - a.createdAt),
      transactions,
      settings: finalSettings,
      presets: presets.length > 0 ? presets : DEFAULT_PRESETS,
    };
  } catch (err) {
    console.warn('IndexedDB fallback to localStorage:', err);
    const raw = localStorage.getItem('vit_messmate_fallback');
    if (raw) {
      return JSON.parse(raw);
    }
    const seed = createDefaultCycleAndSeedData();
    localStorage.setItem('vit_messmate_fallback', JSON.stringify(seed));
    return seed;
  }
}

export async function saveAllDataToDB(
  cycles: BillingCycle[],
  transactions: MealTransaction[],
  settings: AppSettings,
  presets: FoodPreset[]
): Promise<void> {
  try {
    const db = await openDatabase();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(
        [STORE_CYCLES, STORE_TRANSACTIONS, STORE_PRESETS, STORE_SETTINGS],
        'readwrite'
      );

      const cycleStore = tx.objectStore(STORE_CYCLES);
      cycleStore.clear();
      for (const c of cycles) cycleStore.put(c);

      const txStore = tx.objectStore(STORE_TRANSACTIONS);
      txStore.clear();
      for (const t of transactions) txStore.put(t);

      const presetStore = tx.objectStore(STORE_PRESETS);
      presetStore.clear();
      for (const p of presets) presetStore.put(p);

      const settingsStore = tx.objectStore(STORE_SETTINGS);
      settingsStore.put({ id: 'app_settings', value: settings });

      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
    db.close();
  } catch {
    localStorage.setItem(
      'vit_messmate_fallback',
      JSON.stringify({ cycles, transactions, settings, presets })
    );
  }
}
