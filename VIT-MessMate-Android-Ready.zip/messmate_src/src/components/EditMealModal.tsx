import React, { useState } from 'react';
import { MEAL_CATEGORIES, MealCategory, MealTransaction } from '../types/mess';
import { isValidCreditAmount, roundCredits } from '../utils/calculations';
import { Save, X } from 'lucide-react';

interface EditMealModalProps {
  transaction: MealTransaction;
  onClose: () => void;
  onSave: (updated: MealTransaction) => void;
}

export const EditMealModal: React.FC<EditMealModalProps> = ({
  transaction,
  onClose,
  onSave,
}) => {
  const [foodName, setFoodName] = useState(transaction.foodName);
  const [category, setCategory] = useState<MealCategory>(transaction.category);
  const [credits, setCredits] = useState(String(transaction.credits));
  const [quantity, setQuantity] = useState(String(transaction.quantity || 1));
  const [date, setDate] = useState(transaction.date);
  const [time, setTime] = useState(transaction.time);
  const [notes, setNotes] = useState(transaction.notes || '');
  const [tags, setTags] = useState((transaction.tags || []).join(', '));
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const totalVal = parseFloat(credits);
    const qtyVal = parseFloat(quantity || '1');

    if (!foodName.trim()) {
      setError('Food item name cannot be empty.');
      return;
    }
    if (!isValidCreditAmount(totalVal)) {
      setError('Credit amount must be a valid positive number.');
      return;
    }
    if (!Number.isFinite(qtyVal) || qtyVal <= 0) {
      setError('Quantity must be at least 1.');
      return;
    }

    const parsedTags = tags
      .split(',')
      .map((t) => t.trim())
      .filter(Boolean);

    onSave({
      ...transaction,
      foodName: foodName.trim(),
      category,
      credits: roundCredits(totalVal),
      unitCredits: roundCredits(totalVal / qtyVal),
      quantity: qtyVal,
      date,
      time: time || '12:00',
      notes: notes.trim() || undefined,
      tags: parsedTags.length > 0 ? parsedTags : undefined,
      updatedAt: Date.now(),
    });
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="edit-meal-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4"
    >
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-lg rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-xl space-y-4"
      >
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <h3
            id="edit-meal-modal-title"
            className="text-base font-bold text-slate-900 dark:text-white"
          >
            Edit Meal Transaction
          </h3>
          <button
            type="button"
            aria-label="Close edit modal"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {error && (
          <div
            role="alert"
            className="rounded-xl border border-rose-500/40 bg-rose-500/10 px-3.5 py-2 text-xs font-semibold text-rose-600 dark:text-rose-400"
          >
            {error}
          </div>
        )}

        <div>
          <span className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
            Meal Category
          </span>
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
            {MEAL_CATEGORIES.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setCategory(cat)}
                className={`py-1.5 px-2 rounded-lg text-xs font-semibold border transition-colors cursor-pointer ${
                  category === cat
                    ? 'border-emerald-500 bg-emerald-500/15 text-emerald-700 dark:text-emerald-300'
                    : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
          <div className="sm:col-span-6">
            <label
              htmlFor="edit-food-name"
              className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
            >
              Food Item Name
            </label>
            <input
              id="edit-food-name"
              type="text"
              value={foodName}
              onChange={(e) => setFoodName(e.target.value)}
              required
              className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2 text-xs text-slate-900 dark:text-white"
            />
          </div>
          <div className="sm:col-span-4">
            <label
              htmlFor="edit-food-credits"
              className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
            >
              Total Credit Amount
            </label>
            <input
              id="edit-food-credits"
              type="number"
              step="any"
              min="0.01"
              value={credits}
              onChange={(e) => setCredits(e.target.value)}
              required
              className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2 text-xs font-mono font-bold text-slate-900 dark:text-white tabular-nums"
            />
          </div>
          <div className="sm:col-span-2">
            <label
              htmlFor="edit-food-qty"
              className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
            >
              Qty
            </label>
            <input
              id="edit-food-qty"
              type="number"
              min="1"
              value={quantity}
              onChange={(e) => setQuantity(e.target.value)}
              className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-2.5 py-2 text-xs font-mono text-slate-900 dark:text-white tabular-nums"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label
              htmlFor="edit-food-date"
              className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
            >
              Date
            </label>
            <input
              id="edit-food-date"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              required
              className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2 text-xs font-mono text-slate-900 dark:text-white"
            />
          </div>
          <div>
            <label
              htmlFor="edit-food-time"
              className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
            >
              Time
            </label>
            <input
              id="edit-food-time"
              type="time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
              required
              className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2 text-xs font-mono text-slate-900 dark:text-white"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label
              htmlFor="edit-food-notes"
              className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1"
            >
              Notes
            </label>
            <input
              id="edit-food-notes"
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2 text-xs text-slate-900 dark:text-white"
            />
          </div>
          <div>
            <label
              htmlFor="edit-food-tags"
              className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1"
            >
              Tags (comma-separated)
            </label>
            <input
              id="edit-food-tags"
              type="text"
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2 text-xs text-slate-900 dark:text-white"
            />
          </div>
        </div>

        <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="inline-flex items-center gap-1.5 px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-bold text-white cursor-pointer"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Update Meal & Recalculate</span>
          </button>
        </div>
      </form>
    </div>
  );
};
