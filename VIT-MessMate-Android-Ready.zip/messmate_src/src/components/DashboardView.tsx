import React, { useMemo, useState } from 'react';
import {
  BillingCycle,
  CycleMetrics,
  FoodPreset,
  MEAL_CATEGORIES,
  MealCategory,
  MealTransaction,
  SmartInsight,
} from '../types/mess';
import {
  addDaysToDateString,
  buildDailySummaries,
  calculateScenarioProjections,
  calculateTodayBreakdown,
  formatCredits,
  toLocalDateString,
  toLocalTimeString,
} from '../utils/calculations';
import {
  AlertTriangle,
  ArrowUpRight,
  Calendar as CalendarIcon,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Clock,
  Copy,
  Edit3,
  Plus,
  Sliders,
  Trash2,
  TrendingDown,
  TrendingUp,
  Utensils,
  Zap,
} from 'lucide-react';

interface DashboardViewProps {
  cycle: BillingCycle;
  metrics: CycleMetrics;
  transactions: MealTransaction[];
  presets: FoodPreset[];
  insights: SmartInsight[];
  creditFormat: 'integer-preferred' | 'two-decimals';
  lowBalanceThreshold: number;
  overspendingAlertEnabled: boolean;
  onQuickAddMeal: (preset: {
    foodName: string;
    category: MealCategory;
    credits: number;
    date?: string;
    tags?: string[];
  }) => void;
  onDuplicateLastMeal: () => void;
  onNavigateToAdd: (prefillDate?: string) => void;
  onEditTransaction: (tx: MealTransaction) => void;
  onDeleteTransaction: (id: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  cycle,
  metrics,
  transactions,
  presets,
  insights,
  creditFormat,
  lowBalanceThreshold,
  overspendingAlertEnabled,
  onQuickAddMeal,
  onDuplicateLastMeal,
  onNavigateToAdd,
  onEditTransaction,
  onDeleteTransaction,
}) => {
  const [subTab, setSubTab] = useState<'overview' | 'today' | 'calendar'>('overview');
  const [customScenarioSpend, setCustomScenarioSpend] = useState<string>('310');
  const todayStr = toLocalDateString();
  const [selectedCalendarDate, setSelectedCalendarDate] = useState<string>(todayStr);

  const cycleTransactions = useMemo(
    () =>
      transactions
        .filter((t) => t.cycleId === cycle.id)
        .sort((a, b) => b.date.localeCompare(a.date) || b.time.localeCompare(a.time) || b.createdAt - a.createdAt),
    [transactions, cycle.id]
  );

  const todayBreakdown = useMemo(
    () => calculateTodayBreakdown(cycleTransactions, cycle.dailyReference, todayStr, cycle.id),
    [cycleTransactions, cycle.dailyReference, todayStr, cycle.id]
  );

  const parsedCustomSpend = useMemo(() => {
    const val = parseFloat(customScenarioSpend);
    return Number.isFinite(val) && val >= 0 ? val : undefined;
  }, [customScenarioSpend]);

  const scenarios = useMemo(
    () => calculateScenarioProjections(metrics, parsedCustomSpend),
    [metrics, parsedCustomSpend]
  );

  const dailySummaries = useMemo(
    () => buildDailySummaries(cycle.startDate, cycle.endDate, cycleTransactions, cycle.dailyReference),
    [cycle.startDate, cycle.endDate, cycleTransactions, cycle.dailyReference]
  );

  const selectedDaySummary = useMemo(() => {
    const existing = dailySummaries.find((d) => d.date === selectedCalendarDate);
    if (existing) return existing;
    const dayTx = cycleTransactions.filter((t) => t.date === selectedCalendarDate);
    const total = dayTx.reduce((s, t) => s + t.credits, 0);
    return {
      date: selectedCalendarDate,
      totalCredits: total,
      mealCount: dayTx.length,
      status: total === 0 ? ('no-data' as const) : total > cycle.dailyReference ? ('above' as const) : ('below' as const),
      transactions: dayTx,
    };
  }, [dailySummaries, selectedCalendarDate, cycleTransactions, cycle.dailyReference]);

  // Circular gauge SVG parameters
  const radius = 58;
  const circumference = 2 * Math.PI * radius;
  const clampedPct = Math.min(100, Math.max(0, metrics.percentageUsed));
  const strokeDashoffset = circumference - (clampedPct / 100) * circumference;

  const lastRecordedMeal = cycleTransactions[0];

  return (
    <div className="space-y-6">
      {/* Alerts Banner (Low Balance or Overspending Pace) */}
      {overspendingAlertEnabled && metrics.remainingCredits < lowBalanceThreshold && !metrics.isCycleEnded && (
        <div
          role="alert"
          className="rounded-xl border border-amber-500/30 bg-amber-500/10 px-4 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
        >
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
            <div className="text-xs text-slate-800 dark:text-slate-200">
              <span className="font-semibold">Low Remaining Balance Alert: </span>
              You have{' '}
              <span className="font-mono font-semibold tabular-nums">
                {formatCredits(metrics.remainingCredits, creditFormat)} cr
              </span>{' '}
              left for the remaining {metrics.daysRemaining} days. Aim for{' '}
              <span className="font-mono font-semibold tabular-nums">
                {formatCredits(metrics.recommendedDailyAllowance, creditFormat)} cr/day
              </span>{' '}
              to stay within budget.
            </div>
          </div>
          <button
            type="button"
            onClick={() => setSubTab('overview')}
            className="text-xs font-semibold text-amber-600 dark:text-amber-400 hover:underline whitespace-nowrap shrink-0 self-end sm:self-center cursor-pointer"
          >
            View Scenarios
          </button>
        </div>
      )}

      {/* Workspace Sub-Navigation Tabs (Overview & Smart Allowance | Today's Spending | Cycle Calendar) */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
            Mess Credit Dashboard
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 font-mono tabular-nums">
            {cycle.name.includes(cycle.startDate)
              ? `${cycle.name} (${metrics.cycleDuration} days)`
              : `${cycle.name} · ${cycle.startDate} to ${cycle.endDate}`}
          </p>
        </div>

        <div
          role="tablist"
          aria-label="Dashboard sections"
          className="grid grid-cols-3 sm:inline-flex items-center gap-1 p-1 rounded-xl bg-slate-200/70 dark:bg-slate-800/80 w-full sm:w-auto"
        >
          <button
            type="button"
            role="tab"
            aria-selected={subTab === 'overview'}
            onClick={() => setSubTab('overview')}
            className={`px-2 sm:px-3.5 py-2 text-[11px] sm:text-xs font-semibold rounded-lg transition-colors whitespace-nowrap truncate cursor-pointer ${
              subTab === 'overview'
                ? 'bg-white dark:bg-[#111C33] text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Overview
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={subTab === 'today'}
            onClick={() => setSubTab('today')}
            className={`px-2 sm:px-3.5 py-2 text-[11px] sm:text-xs font-semibold rounded-lg transition-colors whitespace-nowrap truncate cursor-pointer ${
              subTab === 'today'
                ? 'bg-white dark:bg-[#111C33] text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Today ({formatCredits(todayBreakdown.totalSpent, creditFormat)} cr)
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={subTab === 'calendar'}
            onClick={() => setSubTab('calendar')}
            className={`px-2 sm:px-3.5 py-2 text-[11px] sm:text-xs font-semibold rounded-lg transition-colors whitespace-nowrap truncate cursor-pointer ${
              subTab === 'calendar'
                ? 'bg-white dark:bg-[#111C33] text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Calendar
          </button>
        </div>
      </div>

      {/* Hero Row: Monthly Credit Overview + Dynamic Daily Allowance */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
        {/* A. Monthly Credit Overview Card */}
        <section
          aria-label="Monthly Credit Overview"
          className="lg:col-span-7 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111C33] p-5 sm:p-6 flex flex-col justify-between"
        >
          <div className="flex items-start justify-between gap-3">
            <div>
              <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
                Monthly Credit Overview
              </span>
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white mt-1 font-mono tabular-nums">
                {formatCredits(metrics.remainingCredits, creditFormat)}{' '}
                <span className="text-xs sm:text-sm font-normal text-slate-500 dark:text-slate-400 whitespace-nowrap">
                  credits left
                </span>
              </h2>
            </div>
            <div className="text-right font-mono tabular-nums shrink-0">
              <span className="text-[11px] sm:text-xs text-slate-500 dark:text-slate-400 block">
                Cycle Timeline
              </span>
              <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 whitespace-nowrap">
                {metrics.daysElapsed}d elapsed · {metrics.daysRemaining}d left
              </span>
            </div>
          </div>

          <div className="my-6 flex flex-col sm:flex-row items-center gap-6">
            {/* Circular Monthly Budget Progress */}
            <div className="relative w-36 h-36 flex items-center justify-center shrink-0">
              <svg className="w-36 h-36 -rotate-90" viewBox="0 0 140 140">
                <circle
                  cx="70"
                  cy="70"
                  r={radius}
                  fill="transparent"
                  stroke="currentColor"
                  strokeWidth="12"
                  className="text-slate-100 dark:text-slate-800"
                />
                <circle
                  cx="70"
                  cy="70"
                  r={radius}
                  fill="transparent"
                  stroke="currentColor"
                  strokeWidth="12"
                  strokeDasharray={circumference}
                  strokeDashoffset={strokeDashoffset}
                  strokeLinecap="round"
                  className={
                    metrics.remainingCredits < 0
                      ? 'text-rose-500 transition-all duration-300'
                      : metrics.percentageUsed > 85
                      ? 'text-amber-500 transition-all duration-300'
                      : 'text-emerald-500 transition-all duration-300'
                  }
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                <span className="text-xl font-bold font-mono tabular-nums text-slate-900 dark:text-white">
                  {formatCredits(metrics.percentageUsed, 'integer-preferred')}%
                </span>
                <span className="text-[11px] text-slate-500 dark:text-slate-400">
                  of budget used
                </span>
              </div>
            </div>

            {/* Key Ledger Figures */}
            <div className="w-full grid grid-cols-2 gap-y-4 gap-x-6 border-t sm:border-t-0 sm:border-l border-slate-100 dark:border-slate-800/80 pt-4 sm:pt-0 sm:pl-6">
              <div>
                <div className="text-xs text-slate-500 dark:text-slate-400">
                  Allocated Budget
                </div>
                <div
                  data-testid="metric-allocated-budget"
                  className="text-base sm:text-lg font-bold font-mono tabular-nums text-slate-900 dark:text-white mt-0.5"
                >
                  {formatCredits(metrics.monthlyBudget, creditFormat)} cr
                </div>
              </div>
              <div>
                <div className="text-xs text-slate-500 dark:text-slate-400">
                  Credits Consumed
                </div>
                <div
                  data-testid="metric-total-used"
                  className="text-base sm:text-lg font-bold font-mono tabular-nums text-emerald-600 dark:text-emerald-400 mt-0.5"
                >
                  {formatCredits(metrics.totalUsed, creditFormat)} cr
                </div>
              </div>
              <div>
                <div className="text-xs text-slate-500 dark:text-slate-400">
                  Remaining Credits
                </div>
                <div
                  data-testid="metric-remaining-credits"
                  className={`text-base sm:text-lg font-bold font-mono tabular-nums mt-0.5 ${
                    metrics.remainingCredits < 0
                      ? 'text-rose-600 dark:text-rose-400'
                      : 'text-slate-900 dark:text-white'
                  }`}
                >
                  {formatCredits(metrics.remainingCredits, creditFormat)} cr
                </div>
              </div>
              <div>
                <div className="text-xs text-slate-500 dark:text-slate-400">
                  Daily Reference
                </div>
                <div className="text-base sm:text-lg font-bold font-mono tabular-nums text-slate-700 dark:text-slate-300 mt-0.5">
                  {formatCredits(metrics.dailyReference, creditFormat)} cr/day
                </div>
              </div>
            </div>
          </div>

          {/* Used vs Remaining Horizontal Bar */}
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-1.5 text-xs text-slate-500 dark:text-slate-400">
            <span>
              Cycle window: <strong className="text-slate-700 dark:text-slate-300 font-mono tabular-nums">{cycle.startDate}</strong> to{' '}
              <strong className="text-slate-700 dark:text-slate-300 font-mono tabular-nums">{cycle.endDate}</strong> ({metrics.cycleDuration}d)
            </span>
            <span className="font-mono tabular-nums">
              Avg so far: <strong className="text-slate-700 dark:text-slate-200">{formatCredits(metrics.averageDailySpendSoFar, creditFormat)} cr/day</strong>
            </span>
          </div>
        </section>

        {/* B. Dynamic Daily Allowance Hero Card */}
        <section
          aria-label="Dynamic Daily Allowance"
          className="lg:col-span-5 rounded-2xl border border-emerald-500/30 dark:border-emerald-500/25 bg-gradient-to-br from-emerald-950/5 via-white to-teal-950/5 dark:from-[#0F2429] dark:via-[#111C33] dark:to-[#0D192B] p-5 sm:p-6 flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-semibold text-emerald-700 dark:text-emerald-400">
                Smart Daily Allowance
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
                {metrics.isCycleEnded
                  ? 'Cycle Ended'
                  : `${metrics.daysRemaining} day${metrics.daysRemaining === 1 ? '' : 's'} remaining`}
              </span>
            </div>

            {metrics.isCycleEnded ? (
              <div className="mt-4">
                <div className="text-2xl font-bold text-slate-900 dark:text-white">
                  Billing Cycle Completed
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                  This cycle has 0 remaining days. Start a new billing cycle in Settings when your next VIT mess month begins.
                </p>
              </div>
            ) : (
              <div className="mt-3">
                <div
                  data-testid="metric-recommended-allowance"
                  className="text-3xl sm:text-4xl font-extrabold font-mono tabular-nums text-slate-900 dark:text-white tracking-tight"
                >
                  {formatCredits(metrics.recommendedDailyAllowance, creditFormat)}{' '}
                  <span className="text-base font-semibold text-emerald-600 dark:text-emerald-400">
                    cr / day
                  </span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-1.5 font-mono tabular-nums">
                  Formula: {formatCredits(metrics.remainingCredits, creditFormat)} remaining ÷ {metrics.daysRemaining} days
                </p>
              </div>
            )}

            {/* Spending Pace Status Indicator */}
            <div className="mt-5 pt-4 border-t border-slate-200/70 dark:border-slate-800/80">
              {metrics.remainingCredits < 0 ? (
                <div className="flex items-start gap-2.5 text-xs text-rose-600 dark:text-rose-400">
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>
                    <strong>Monthly budget exceeded:</strong> You have spent{' '}
                    {formatCredits(Math.abs(metrics.remainingCredits), creditFormat)} cr above your{' '}
                    {formatCredits(metrics.monthlyBudget, creditFormat)} cr budget. Meal logging remains unrestricted.
                  </span>
                </div>
              ) : metrics.recommendedDailyAllowance >= metrics.dailyReference ? (
                <div className="flex items-start gap-2.5 text-xs text-emerald-700 dark:text-emerald-300">
                  <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-500" />
                  <span>
                    <strong>Positive Buffer (+{formatCredits(metrics.recommendedDailyAllowance - metrics.dailyReference, creditFormat)} cr/day):</strong>{' '}
                    Your unused credits carried forward! You can spend up to{' '}
                    <strong className="font-mono tabular-nums">
                      {formatCredits(metrics.recommendedDailyAllowance, creditFormat)} cr/day
                    </strong>{' '}
                    versus the {formatCredits(metrics.dailyReference, creditFormat)} cr reference.
                  </span>
                </div>
              ) : (
                <div className="flex items-start gap-2.5 text-xs text-amber-700 dark:text-amber-300">
                  <TrendingDown className="w-4 h-4 shrink-0 mt-0.5 text-amber-500" />
                  <span>
                    <strong>Adjusted Pace ({formatCredits(metrics.recommendedDailyAllowance - metrics.dailyReference, creditFormat)} cr/day vs reference):</strong>{' '}
                    Spending was above the {formatCredits(metrics.dailyReference, creditFormat)} cr reference earlier. Keep daily meals near{' '}
                    <strong className="font-mono tabular-nums">
                      {formatCredits(metrics.recommendedDailyAllowance, creditFormat)} cr
                    </strong>{' '}
                    to finish comfortably on budget.
                  </span>
                </div>
              )}
            </div>
          </div>

          <div className="mt-5 flex items-center gap-2.5">
            <button
              type="button"
              onClick={() => onNavigateToAdd()}
              className="flex-1 inline-flex items-center justify-center gap-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs py-2.5 px-4 transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Record Meal</span>
            </button>
            {lastRecordedMeal && (
              <button
                type="button"
                onClick={onDuplicateLastMeal}
                title={`Duplicate last meal: ${lastRecordedMeal.foodName} (${lastRecordedMeal.credits} cr)`}
                className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/90 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 font-semibold text-xs py-2.5 px-3.5 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Copy className="w-3.5 h-3.5 text-emerald-500" />
                <span>Repeat Last ({formatCredits(lastRecordedMeal.credits, creditFormat)} cr)</span>
              </button>
            )}
          </div>
        </section>
      </div>

      {/* SUB-TAB 1: OVERVIEW, QUICK ADD, SMART ALLOWANCE SCENARIOS & INSIGHTS */}
      {subTab === 'overview' && (
        <div className="space-y-6">
          {/* Quick-Add Common VIT Meals Strip */}
          <section
            aria-label="Quick Add Common Meals"
            className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111C33] p-5"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3.5">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Zap className="w-4 h-4 text-emerald-500" />
                  <span>1-Tap Quick Add Meal</span>
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Instantly log a meal for today ({todayStr}) and recalculate your daily allowance.
                </p>
              </div>
              <button
                type="button"
                onClick={() => onNavigateToAdd()}
                className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline self-start sm:self-auto cursor-pointer"
              >
                Custom food or multiple items &rarr;
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {presets.slice(0, 4).map((preset) => (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() =>
                    onQuickAddMeal({
                      foodName: preset.foodName,
                      category: preset.category,
                      credits: preset.credits,
                      tags: preset.tags,
                    })
                  }
                  className="group text-left rounded-xl border border-slate-200 dark:border-slate-800 hover:border-emerald-500/60 dark:hover:border-emerald-500/50 bg-slate-50/70 dark:bg-slate-900/50 hover:bg-emerald-500/5 p-3 transition-colors cursor-pointer"
                >
                  <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                    <span>{preset.category}</span>
                    <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">
                      +{formatCredits(preset.credits, creditFormat)} cr
                    </span>
                  </div>
                  <div className="text-xs font-semibold text-slate-900 dark:text-white mt-1 truncate">
                    {preset.foodName}
                  </div>
                </button>
              ))}
            </div>
          </section>

          {/* Smart Daily Allowance Scenario Engine */}
          <section
            aria-label="Smart Daily Allowance Engine and Scenarios"
            className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111C33] p-5 sm:p-6"
          >
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-slate-100 dark:border-slate-800">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-emerald-500" />
                  <span>Smart Daily Allowance Simulator</span>
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Compare how different daily spending paces affect your end-of-cycle balance across the remaining{' '}
                  <strong className="font-mono tabular-nums text-slate-700 dark:text-slate-200">
                    {metrics.daysRemaining} days
                  </strong>
                  .
                </p>
              </div>

              {/* Custom Future Daily Spending Input */}
              <div className="flex items-center gap-2.5 bg-slate-50 dark:bg-slate-900/70 border border-slate-200 dark:border-slate-800 rounded-xl px-3.5 py-2">
                <label
                  htmlFor="custom-scenario-input"
                  className="text-xs font-medium text-slate-600 dark:text-slate-300 whitespace-nowrap"
                >
                  Custom daily spend:
                </label>
                <input
                  id="custom-scenario-input"
                  type="number"
                  min="0"
                  step="5"
                  value={customScenarioSpend}
                  onChange={(e) => setCustomScenarioSpend(e.target.value)}
                  className="w-20 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-2.5 py-1 text-xs font-mono font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 tabular-nums"
                />
                <span className="text-xs font-mono text-slate-500 dark:text-slate-400">
                  cr/day
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-5">
              {scenarios.map((sc) => (
                <div
                  key={sc.id}
                  className="rounded-xl border border-slate-200/80 dark:border-slate-800/90 bg-slate-50/50 dark:bg-slate-900/40 p-4 flex flex-col justify-between"
                >
                  <div>
                    <div className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                      {sc.label}
                    </div>
                    <div className="mt-2 flex items-baseline gap-1.5 font-mono tabular-nums">
                      <span className="text-xl font-bold text-slate-900 dark:text-white">
                        {formatCredits(sc.dailySpend, creditFormat)}
                      </span>
                      <span className="text-xs text-slate-500 dark:text-slate-400">
                        cr × {metrics.daysRemaining}d = {formatCredits(sc.totalFutureSpend, creditFormat)} cr
                      </span>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-200/60 dark:border-slate-800/80 space-y-1.5 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500 dark:text-slate-400">Projected Total:</span>
                      <span className="font-mono font-semibold tabular-nums text-slate-800 dark:text-slate-200">
                        {formatCredits(sc.projectedTotalUsed, creditFormat)} / {formatCredits(metrics.monthlyBudget, creditFormat)} cr
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500 dark:text-slate-400">Cycle End Balance:</span>
                      <span
                        className={`font-mono font-bold tabular-nums ${
                          sc.willExceedBudget
                            ? 'text-rose-600 dark:text-rose-400'
                            : 'text-emerald-600 dark:text-emerald-400'
                        }`}
                      >
                        {sc.projectedEndBalance >= 0 ? '+' : ''}
                        {formatCredits(sc.projectedEndBalance, creditFormat)} cr
                      </span>
                    </div>
                    <div className="pt-1 text-[11px] font-medium">
                      {sc.willExceedBudget ? (
                        <span className="text-rose-600 dark:text-rose-400">
                          Exceeds monthly budget by {formatCredits(Math.abs(sc.projectedEndBalance), creditFormat)} cr
                          {sc.daysUntilDepleted !== null ? ` (lasts ~${sc.daysUntilDepleted}d)` : ''}
                        </span>
                      ) : (
                        <span className="text-emerald-600 dark:text-emerald-400">
                          Sustainable — finishes with {formatCredits(sc.projectedEndBalance, creditFormat)} cr left
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Bottom Split: Today's Snapshot + Live Smart Insights */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            {/* Today's Quick Summary */}
            <section
              aria-label="Today's Spending Summary"
              className="lg:col-span-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111C33] p-5 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-base font-bold text-slate-900 dark:text-white">
                      Today&apos;s Spending ({todayStr})
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      {todayBreakdown.mealCount} meal{todayBreakdown.mealCount === 1 ? '' : 's'} recorded today · Reference: {formatCredits(cycle.dailyReference, creditFormat)} cr
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setSubTab('today')}
                    className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline inline-flex items-center gap-1 cursor-pointer"
                  >
                    <span>Full Today View</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="mt-4 grid grid-cols-3 gap-3 p-3.5 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200/70 dark:border-slate-800/80 font-mono tabular-nums">
                  <div>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400 block font-sans">
                      Today&apos;s Reference
                    </span>
                    <span className="text-base font-bold text-slate-800 dark:text-slate-200">
                      {formatCredits(todayBreakdown.dailyReference, creditFormat)} cr
                    </span>
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400 block font-sans">
                      Today&apos;s Spending
                    </span>
                    <span
                      data-testid="today-total-spent"
                      className="text-base font-bold text-emerald-600 dark:text-emerald-400"
                    >
                      {formatCredits(todayBreakdown.totalSpent, creditFormat)} cr
                    </span>
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400 block font-sans">
                      Difference
                    </span>
                    <span
                      className={`text-base font-bold ${
                        todayBreakdown.differenceFromReference > 0
                          ? 'text-amber-600 dark:text-amber-400'
                          : 'text-emerald-600 dark:text-emerald-400'
                      }`}
                    >
                      {todayBreakdown.differenceFromReference > 0 ? '+' : ''}
                      {formatCredits(todayBreakdown.differenceFromReference, creditFormat)} cr
                    </span>
                  </div>
                </div>

                <div className="mt-4 grid grid-cols-4 gap-2 text-center">
                  {(['Breakfast', 'Lunch', 'Snacks', 'Dinner'] as MealCategory[]).map((cat) => (
                    <div
                      key={cat}
                      className="rounded-lg border border-slate-100 dark:border-slate-800/80 p-2.5"
                    >
                      <div className="text-[11px] text-slate-500 dark:text-slate-400">{cat}</div>
                      <div className="text-xs font-bold font-mono tabular-nums text-slate-900 dark:text-white mt-0.5">
                        {formatCredits(todayBreakdown.byCategory[cat], creditFormat)} cr
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <p className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400">
                Note: Spending above {formatCredits(cycle.dailyReference, creditFormat)} cr on a single day is completely allowed; your remaining monthly budget and daily allowance adjust automatically.
              </p>
            </section>

            {/* Real-time Smart Insights */}
            <section
              aria-label="Smart Insights"
              className="lg:col-span-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111C33] p-5"
            >
              <div className="flex items-center justify-between mb-3.5">
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    Smart Insights
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Calculated dynamically from your {cycleTransactions.length} recorded meal{cycleTransactions.length === 1 ? '' : 's'}
                  </p>
                </div>
              </div>

              <div className="divide-y divide-slate-100 dark:divide-slate-800/80">
                {insights.slice(0, 4).map((ins) => (
                  <div key={ins.id} className="py-3 first:pt-1 last:pb-1 flex items-start justify-between gap-4">
                    <div>
                      <div className="text-xs font-semibold text-slate-900 dark:text-white flex items-center gap-1.5">
                        {ins.type === 'positive' && (
                          <TrendingDown className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                        )}
                        {ins.type === 'warning' && (
                          <TrendingUp className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                        )}
                        <span>{ins.title}</span>
                      </div>
                      <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5 leading-relaxed">
                        {ins.description}
                      </p>
                    </div>
                    {ins.metric && (
                      <span className="font-mono text-xs font-bold tabular-nums text-emerald-600 dark:text-emerald-400 whitespace-nowrap shrink-0">
                        {ins.metric}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </section>
          </div>
        </div>
      )}

      {/* SUB-TAB 2: DEDICATED TODAY'S SPENDING SCREEN */}
      {subTab === 'today' && (
        <section
          aria-label="Today's Spending Detailed Screen"
          className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111C33] p-5 sm:p-6 space-y-6"
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                Today&apos;s Spending Breakdown ({todayStr})
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Spending above {formatCredits(cycle.dailyReference, creditFormat)} credits is allowed without restriction — your remaining monthly budget is automatically recalculated.
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigateToAdd(todayStr)}
              className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 px-4 py-2.5 text-xs font-semibold text-white transition-colors self-start sm:self-auto cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add Meal for Today</span>
            </button>
          </div>

          {/* Reference vs Today Comparison Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 font-mono tabular-nums">
            <div className="rounded-xl border border-slate-200/80 dark:border-slate-800 p-4">
              <div className="text-xs font-sans text-slate-500 dark:text-slate-400">
                Today&apos;s Reference
              </div>
              <div className="text-xl font-bold text-slate-900 dark:text-white mt-1">
                {formatCredits(todayBreakdown.dailyReference, creditFormat)} cr
              </div>
            </div>
            <div className="rounded-xl border border-slate-200/80 dark:border-slate-800 p-4">
              <div className="text-xs font-sans text-slate-500 dark:text-slate-400">
                Today&apos;s Spending
              </div>
              <div className="text-xl font-bold text-emerald-600 dark:text-emerald-400 mt-1">
                {formatCredits(todayBreakdown.totalSpent, creditFormat)} cr
              </div>
            </div>
            <div className="rounded-xl border border-slate-200/80 dark:border-slate-800 p-4">
              <div className="text-xs font-sans text-slate-500 dark:text-slate-400">
                Difference vs Reference
              </div>
              <div
                className={`text-xl font-bold mt-1 ${
                  todayBreakdown.differenceFromReference > 0
                    ? 'text-amber-600 dark:text-amber-400'
                    : 'text-emerald-600 dark:text-emerald-400'
                }`}
              >
                {todayBreakdown.differenceFromReference > 0 ? '+' : ''}
                {formatCredits(todayBreakdown.differenceFromReference, creditFormat)} cr
              </div>
            </div>
            <div className="rounded-xl border border-slate-200/80 dark:border-slate-800 p-4">
              <div className="text-xs font-sans text-slate-500 dark:text-slate-400">
                Meals Recorded Today
              </div>
              <div className="text-xl font-bold text-slate-900 dark:text-white mt-1">
                {todayBreakdown.mealCount}
              </div>
            </div>
          </div>

          {/* Category Totals (Breakfast, Lunch, Snacks, Dinner, Beverages, Other) */}
          <div>
            <h4 className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-3">
              Category Totals Today
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              {MEAL_CATEGORIES.map((cat) => (
                <div
                  key={cat}
                  className="rounded-xl border border-slate-200/70 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/40 p-3"
                >
                  <div className="text-xs text-slate-600 dark:text-slate-400">{cat}</div>
                  <div className="text-base font-bold font-mono tabular-nums text-slate-900 dark:text-white mt-1">
                    {formatCredits(todayBreakdown.byCategory[cat], creditFormat)} cr
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Individual Food Entries Today */}
          <div>
            <h4 className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-3">
              Today&apos;s Individual Food Entries
            </h4>
            {todayBreakdown.transactions.length === 0 ? (
              <div className="rounded-xl border border-dashed border-slate-200 dark:border-slate-800 p-8 text-center">
                <Utensils className="w-6 h-6 text-slate-400 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                  No meals recorded for today ({todayStr}) yet
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Use Quick Add or click below to record your first meal today.
                </p>
                <button
                  type="button"
                  onClick={() => onNavigateToAdd(todayStr)}
                  className="mt-4 inline-flex items-center gap-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 px-4 py-2 text-xs font-semibold text-white cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Record Today&apos;s Meal</span>
                </button>
              </div>
            ) : (
              <div className="divide-y divide-slate-100 dark:divide-slate-800 border-t border-b border-slate-100 dark:border-slate-800">
                {todayBreakdown.transactions.map((tx) => (
                  <div
                    key={tx.id}
                    className="py-3.5 flex items-center justify-between gap-4"
                  >
                    <div className="min-w-0">
                      <div className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                        {tx.foodName}
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 flex flex-wrap items-center gap-1.5">
                        <span>{tx.category}</span>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono tabular-nums">{tx.time}</span>
                        {tx.quantity > 1 && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="font-mono tabular-nums">Qty: {tx.quantity}</span>
                          </>
                        )}
                        {tx.notes && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="italic">{tx.notes}</span>
                          </>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <span className="text-sm font-bold font-mono tabular-nums text-slate-900 dark:text-white">
                        {formatCredits(tx.credits, creditFormat)} cr
                      </span>
                      <button
                        type="button"
                        aria-label={`Edit ${tx.foodName}`}
                        onClick={() => onEditTransaction(tx)}
                        className="p-2 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        aria-label={`Delete ${tx.foodName}`}
                        onClick={() => onDeleteTransaction(tx.id)}
                        className="p-2 rounded-lg text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>
      )}

      {/* SUB-TAB 3: MONTHLY CALENDAR AND DAILY HISTORY */}
      {subTab === 'calendar' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Calendar Grid */}
          <section
            aria-label="Billing Cycle Calendar"
            className="lg:col-span-7 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111C33] p-5 sm:p-6"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <CalendarIcon className="w-4 h-4 text-emerald-500" />
                  <span>Billing Cycle Daily Calendar</span>
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Click any date to inspect its meal history or log a meal for that day.
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-600 dark:text-slate-400">
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded-xs bg-emerald-500/20 border border-emerald-500/50 inline-block" />
                  Below {cycle.dailyReference}
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded-xs bg-sky-500/20 border border-sky-500/50 inline-block" />
                  On Ref (~{cycle.dailyReference})
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded-xs bg-amber-500/20 border border-amber-500/50 inline-block" />
                  Above {cycle.dailyReference}
                </span>
              </div>
            </div>

            <div className="mt-4 grid grid-cols-3 sm:grid-cols-5 md:grid-cols-6 gap-2.5">
              {dailySummaries.map((day, idx) => {
                const isSelected = day.date === selectedCalendarDate;
                const isToday = day.date === todayStr;

                let statusColor =
                  'border-slate-200/80 dark:border-slate-800 bg-slate-50/40 dark:bg-slate-900/30 text-slate-600 dark:text-slate-400';
                if (day.status === 'below') {
                  statusColor =
                    'border-emerald-500/40 bg-emerald-500/10 text-emerald-800 dark:text-emerald-300';
                } else if (day.status === 'on-reference') {
                  statusColor =
                    'border-sky-500/40 bg-sky-500/10 text-sky-800 dark:text-sky-300';
                } else if (day.status === 'above') {
                  statusColor =
                    'border-amber-500/40 bg-amber-500/10 text-amber-800 dark:text-amber-300';
                }

                return (
                  <button
                    key={day.date}
                    type="button"
                    onClick={() => setSelectedCalendarDate(day.date)}
                    className={`text-left rounded-xl border p-2.5 transition-all cursor-pointer ${statusColor} ${
                      isSelected
                        ? 'ring-2 ring-emerald-500 shadow-xs'
                        : 'hover:border-slate-400 dark:hover:border-slate-600'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[11px] font-mono tabular-nums">
                      <span className="font-semibold">Day {idx + 1}</span>
                      {isToday && (
                        <span className="text-[10px] font-sans font-bold text-emerald-600 dark:text-emerald-400">
                          Today
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 font-mono tabular-nums mt-0.5">
                      {day.date.slice(5)}
                    </div>
                    <div className="mt-2 font-mono tabular-nums">
                      <div className="text-xs font-bold text-slate-900 dark:text-white">
                        {day.mealCount > 0
                          ? `${formatCredits(day.totalCredits, creditFormat)} cr`
                          : '—'}
                      </div>
                      <div className="text-[10px] text-slate-500 dark:text-slate-400">
                        {day.mealCount > 0
                          ? `${day.mealCount} meal${day.mealCount === 1 ? '' : 's'}`
                          : 'No data'}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </section>

          {/* Selected Date Detailed History Drawer/Panel */}
          <section
            aria-label="Selected Day Meal History"
            className="lg:col-span-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111C33] p-5 sm:p-6 flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between gap-2 pb-4 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <span className="text-xs text-slate-500 dark:text-slate-400">
                    Selected Date History
                  </span>
                  <h4 className="text-base font-bold font-mono tabular-nums text-slate-900 dark:text-white mt-0.5">
                    {selectedDaySummary.date}
                  </h4>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    aria-label="Previous day"
                    onClick={() =>
                      setSelectedCalendarDate(addDaysToDateString(selectedCalendarDate, -1))
                    }
                    className="p-2 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    aria-label="Next day"
                    onClick={() =>
                      setSelectedCalendarDate(addDaysToDateString(selectedCalendarDate, 1))
                    }
                    className="p-2 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="my-4 grid grid-cols-3 gap-3 p-3.5 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200/70 dark:border-slate-800/80 font-mono tabular-nums">
                <div>
                  <span className="text-[11px] font-sans text-slate-500 dark:text-slate-400 block">
                    Day Total
                  </span>
                  <span className="text-base font-bold text-slate-900 dark:text-white">
                    {formatCredits(selectedDaySummary.totalCredits, creditFormat)} cr
                  </span>
                </div>
                <div>
                  <span className="text-[11px] font-sans text-slate-500 dark:text-slate-400 block">
                    Meals
                  </span>
                  <span className="text-base font-bold text-slate-900 dark:text-white">
                    {selectedDaySummary.mealCount}
                  </span>
                </div>
                <div>
                  <span className="text-[11px] font-sans text-slate-500 dark:text-slate-400 block">
                    Status vs {cycle.dailyReference}
                  </span>
                  <span className="text-xs font-sans font-bold text-emerald-600 dark:text-emerald-400">
                    {selectedDaySummary.status === 'no-data'
                      ? 'No Data'
                      : selectedDaySummary.status === 'below'
                      ? 'Below Ref'
                      : selectedDaySummary.status === 'on-reference'
                      ? 'On Ref'
                      : 'Above Ref'}
                  </span>
                </div>
              </div>

              {selectedDaySummary.transactions.length === 0 ? (
                <div className="py-8 text-center">
                  <Clock className="w-6 h-6 text-slate-400 mx-auto mb-2" />
                  <p className="text-xs font-medium text-slate-600 dark:text-slate-400">
                    No meals recorded on {selectedDaySummary.date}.
                  </p>
                </div>
              ) : (
                <div className="divide-y divide-slate-100 dark:divide-slate-800">
                  {selectedDaySummary.transactions.map((tx) => (
                    <div
                      key={tx.id}
                      className="py-3 flex items-center justify-between gap-3"
                    >
                      <div className="min-w-0">
                        <div className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                          {tx.foodName}
                        </div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                          {tx.category} · <span className="font-mono tabular-nums">{tx.time}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <span className="text-xs font-bold font-mono tabular-nums text-slate-900 dark:text-white">
                          {formatCredits(tx.credits, creditFormat)} cr
                        </span>
                        <button
                          type="button"
                          aria-label={`Edit ${tx.foodName}`}
                          onClick={() => onEditTransaction(tx)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          aria-label={`Delete ${tx.foodName}`}
                          onClick={() => onDeleteTransaction(tx.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={() => onNavigateToAdd(selectedDaySummary.date)}
              className="mt-5 w-full inline-flex items-center justify-center gap-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 py-2.5 px-4 text-xs font-semibold text-white transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Record Meal for {selectedDaySummary.date}</span>
            </button>
          </section>
        </div>
      )}
    </div>
  );
};
