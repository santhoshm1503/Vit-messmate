import {
  BillingCycle,
  CycleMetrics,
  DaySummary,
  MEAL_CATEGORIES,
  MealCategory,
  MealTransaction,
  ScenarioProjection,
  SmartInsight,
  TodayBreakdown,
} from '../types/mess';

/**
 * Prevents floating-point calculation inaccuracies by rounding to 2 decimal places.
 */
export function roundCredits(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

/**
 * Formats a credit value cleanly according to user preference.
 */
export function formatCredits(
  value: number,
  format: 'integer-preferred' | 'two-decimals' = 'integer-preferred'
): string {
  const rounded = roundCredits(value);
  if (format === 'two-decimals') {
    return rounded.toLocaleString('en-IN', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  }
  const isWhole = Math.abs(rounded - Math.round(rounded)) < 0.001;
  return rounded.toLocaleString('en-IN', {
    minimumFractionDigits: isWhole ? 0 : 2,
    maximumFractionDigits: 2,
  });
}

/**
 * Parses a YYYY-MM-DD date string into a UTC-midnight timestamp for exact day-difference math.
 */
export function parseDateUTC(dateStr: string): number {
  const [y, m, d] = dateStr.split('-').map(Number);
  if (!y || !m || !d) return 0;
  return Date.UTC(y, m - 1, d);
}

/**
 * Formats a Date object as local YYYY-MM-DD.
 */
export function toLocalDateString(date: Date = new Date()): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

/**
 * Formats a Date object as local HH:mm.
 */
export function toLocalTimeString(date: Date = new Date()): string {
  const h = String(date.getHours()).padStart(2, '0');
  const min = String(date.getMinutes()).padStart(2, '0');
  return `${h}:${min}`;
}

/**
 * Adds a number of days to a YYYY-MM-DD string and returns the new YYYY-MM-DD string.
 */
export function addDaysToDateString(dateStr: string, daysToAdd: number): string {
  const utc = parseDateUTC(dateStr);
  if (!utc) return dateStr;
  const next = new Date(utc + daysToAdd * 86400000);
  const y = next.getUTCFullYear();
  const m = String(next.getUTCMonth() + 1).padStart(2, '0');
  const d = String(next.getUTCDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

/**
 * Calculates calendar day difference (dateB - dateA) in whole days.
 */
export function diffCalendarDays(dateA: string, dateB: string): number {
  const utcA = parseDateUTC(dateA);
  const utcB = parseDateUTC(dateB);
  return Math.round((utcB - utcA) / 86400000);
}

/**
 * Calculates the end date of a cycle given startDate and cycleDuration (in days).
 * A 30-day cycle starting on Day 1 ends on startDate + 29 days (30 inclusive calendar days).
 */
export function calculateCycleEndDate(startDate: string, cycleDuration: number): string {
  const safeDuration = Math.max(1, Math.floor(cycleDuration));
  return addDaysToDateString(startDate, safeDuration - 1);
}

/**
 * Validates whether a credit input is valid (must be finite and > 0).
 */
export function isValidCreditAmount(amount: number): boolean {
  return typeof amount === 'number' && Number.isFinite(amount) && amount > 0;
}

/**
 * Calculates elapsed and remaining days in the billing cycle.
 * Rules:
 * - Do not count future dates as elapsed days.
 * - Do not count a completed cycle as having remaining days.
 * - Handle zero remaining days safely.
 */
export function calculateCycleDayCounts(
  startDate: string,
  endDate: string,
  cycleDuration: number,
  currentDateStr: string = toLocalDateString()
): {
  daysElapsed: number;
  daysRemaining: number;
  isCycleEnded: boolean;
  isCycleFuture: boolean;
} {
  const totalDays = Math.max(1, Math.floor(cycleDuration));
  const diffFromStart = diffCalendarDays(startDate, currentDateStr);
  const diffFromEnd = diffCalendarDays(endDate, currentDateStr);

  if (diffFromStart < 0) {
    return {
      daysElapsed: 0,
      daysRemaining: totalDays,
      isCycleEnded: false,
      isCycleFuture: true,
    };
  }

  if (diffFromEnd > 0 || diffFromStart >= totalDays) {
    return {
      daysElapsed: totalDays,
      daysRemaining: 0,
      isCycleEnded: true,
      isCycleFuture: false,
    };
  }

  const daysElapsed = Math.min(totalDays, Math.max(0, diffFromStart));
  const daysRemaining = Math.max(0, totalDays - daysElapsed);

  return {
    daysElapsed,
    daysRemaining,
    isCycleEnded: daysRemaining === 0,
    isCycleFuture: false,
  };
}

/**
 * Core dynamic daily allowance calculator.
 * Remaining Credits = Monthly Budget - Total Credits Used
 * Recommended Daily Allowance = Remaining Credits / Remaining Days
 */
export function calculateRecommendedAllowance(
  remainingCredits: number,
  daysRemaining: number
): number {
  if (daysRemaining <= 0 || remainingCredits <= 0) {
    return 0;
  }
  return roundCredits(remainingCredits / daysRemaining);
}

/**
 * Computes comprehensive monthly cycle metrics from a BillingCycle and its transactions.
 */
export function calculateCycleMetrics(
  cycle: BillingCycle,
  transactions: MealTransaction[],
  currentDateStr: string = toLocalDateString()
): CycleMetrics {
  const monthlyBudget = roundCredits(Math.max(0, cycle.monthlyBudget));
  const dailyReference = roundCredits(Math.max(0, cycle.dailyReference));
  const cycleDuration = Math.max(1, Math.floor(cycle.cycleDuration));

  const cycleTransactions = transactions.filter((t) => t.cycleId === cycle.id);
  const totalUsed = roundCredits(
    cycleTransactions.reduce((sum, t) => sum + (Number.isFinite(t.credits) ? t.credits : 0), 0)
  );

  const remainingCredits = roundCredits(monthlyBudget - totalUsed);
  const percentageUsed =
    monthlyBudget > 0 ? roundCredits((totalUsed / monthlyBudget) * 100) : 0;

  const { daysElapsed, daysRemaining, isCycleEnded, isCycleFuture } =
    calculateCycleDayCounts(cycle.startDate, cycle.endDate, cycleDuration, currentDateStr);

  const recommendedDailyAllowance = calculateRecommendedAllowance(
    remainingCredits,
    daysRemaining
  );

  // For average daily spend so far, use distinct active days or elapsed days (at least 1 if transactions exist)
  const effectiveElapsedDays =
    daysElapsed > 0 ? daysElapsed : cycleTransactions.length > 0 ? 1 : 0;
  const averageDailySpendSoFar =
    effectiveElapsedDays > 0
      ? roundCredits(totalUsed / effectiveElapsedDays)
      : 0;

  const projectedEndBalance =
    daysRemaining > 0 && effectiveElapsedDays > 0
      ? roundCredits(remainingCredits - averageDailySpendSoFar * daysRemaining)
      : remainingCredits;

  let spendingPaceStatus: CycleMetrics['spendingPaceStatus'] = 'on-reference';
  if (isCycleEnded) {
    spendingPaceStatus = 'cycle-ended';
  } else if (remainingCredits < 0) {
    spendingPaceStatus = 'over-budget';
  } else if (effectiveElapsedDays > 0) {
    // Compare average daily spend so far against recommended allowance / daily reference
    if (averageDailySpendSoFar > dailyReference * 1.05) {
      spendingPaceStatus = 'above-reference';
    } else if (averageDailySpendSoFar < dailyReference * 0.95) {
      spendingPaceStatus = 'below-reference';
    } else {
      spendingPaceStatus = 'on-reference';
    }
  }

  const isSustainable =
    remainingCredits >= 0 &&
    (effectiveElapsedDays === 0 ||
      daysRemaining === 0 ||
      averageDailySpendSoFar <= recommendedDailyAllowance ||
      projectedEndBalance >= 0);

  return {
    monthlyBudget,
    dailyReference,
    cycleDuration,
    totalUsed,
    remainingCredits,
    percentageUsed,
    daysElapsed,
    daysRemaining,
    isCycleEnded,
    isCycleFuture,
    recommendedDailyAllowance,
    averageDailySpendSoFar,
    spendingPaceStatus,
    projectedEndBalance,
    isSustainable,
  };
}

/**
 * Computes Today's Spending breakdown and difference from the 288-credit (or custom) daily reference.
 */
export function calculateTodayBreakdown(
  transactions: MealTransaction[],
  dailyReference: number = 288,
  todayDateStr: string = toLocalDateString(),
  cycleId?: string
): TodayBreakdown {
  const todaysMeals = transactions
    .filter((t) => t.date === todayDateStr && (!cycleId || t.cycleId === cycleId))
    .sort((a, b) => b.time.localeCompare(a.time) || b.createdAt - a.createdAt);

  const byCategory: Record<MealCategory, number> = {
    Breakfast: 0,
    Lunch: 0,
    Snacks: 0,
    Dinner: 0,
    Beverages: 0,
    Other: 0,
  };

  let totalSpent = 0;
  for (const meal of todaysMeals) {
    totalSpent = roundCredits(totalSpent + meal.credits);
    const cat = MEAL_CATEGORIES.includes(meal.category) ? meal.category : 'Other';
    byCategory[cat] = roundCredits(byCategory[cat] + meal.credits);
  }

  const differenceFromReference = roundCredits(totalSpent - dailyReference);

  return {
    date: todayDateStr,
    totalSpent,
    mealCount: todaysMeals.length,
    dailyReference,
    differenceFromReference,
    byCategory,
    transactions: todaysMeals,
  };
}

/**
 * Builds scenario projections for the Smart Daily Allowance Engine:
 * - Scenario A: Spend the recommended amount every remaining day.
 * - Scenario B: Spend 350 credits daily.
 * - Scenario C: Spend 250 credits daily.
 * - Custom Scenario: User-entered custom daily spend.
 */
export function calculateScenarioProjections(
  metrics: CycleMetrics,
  customDailySpend?: number
): ScenarioProjection[] {
  const buildScenario = (
    id: string,
    label: string,
    dailySpend: number,
    exactFutureTotal?: number
  ): ScenarioProjection => {
    const safeDaily = roundCredits(Math.max(0, dailySpend));
    const totalFutureSpend =
      typeof exactFutureTotal === 'number'
        ? roundCredits(Math.max(0, exactFutureTotal))
        : roundCredits(safeDaily * metrics.daysRemaining);
    const projectedTotalUsed = roundCredits(metrics.totalUsed + totalFutureSpend);
    const projectedEndBalance = roundCredits(metrics.monthlyBudget - projectedTotalUsed);
    const willExceedBudget = projectedEndBalance < -0.01;
    const daysUntilDepleted =
      safeDaily > 0 && metrics.remainingCredits > 0
        ? Math.floor((metrics.remainingCredits / safeDaily) * 10) / 10
        : metrics.remainingCredits <= 0
        ? 0
        : null;

    return {
      id,
      label,
      dailySpend: safeDaily,
      totalFutureSpend,
      projectedTotalUsed,
      projectedEndBalance,
      willExceedBudget,
      daysUntilDepleted,
    };
  };

  const scenarios: ScenarioProjection[] = [
    buildScenario(
      'scenario-a',
      'Scenario A: Recommended Allowance',
      metrics.recommendedDailyAllowance,
      metrics.daysRemaining > 0 ? Math.max(0, metrics.remainingCredits) : 0
    ),
    buildScenario('scenario-b', 'Scenario B: Heavy Pace (350 cr/day)', 350),
    buildScenario('scenario-c', 'Scenario C: Light Pace (250 cr/day)', 250),
  ];

  if (typeof customDailySpend === 'number' && Number.isFinite(customDailySpend) && customDailySpend >= 0) {
    scenarios.push(
      buildScenario(
        'scenario-custom',
        `Custom Pace (${formatCredits(customDailySpend)} cr/day)`,
        customDailySpend
      )
    );
  }

  return scenarios;
}

/**
 * Determines the spending status for a single date relative to dailyReference (default 288):
 * - 'no-data': 0 meals
 * - 'below': < dailyReference * 0.95 (e.g. < 273.6 for 288)
 * - 'on-reference': within ±5% of dailyReference (or equal to 288)
 * - 'above': > dailyReference (specifically > dailyReference)
 * Wait: let's follow Section 6 strictly:
 * "Below 288: Normal. Equal or near 288: On reference. Above 288: Above reference. No recorded meals: No data."
 */
export function getDaySpendingStatus(
  totalCredits: number,
  mealCount: number,
  dailyReference: number = 288
): DaySummary['status'] {
  if (mealCount === 0 && totalCredits === 0) return 'no-data';
  if (totalCredits > dailyReference) return 'above';
  // Equal or near 288 (within 5% below up to 288, e.g. 270..288)
  if (totalCredits >= dailyReference * 0.93 && totalCredits <= dailyReference) {
    return 'on-reference';
  }
  return 'below';
}

/**
 * Generates day-by-day summary map for a date range or billing cycle.
 */
export function buildDailySummaries(
  startDate: string,
  endDate: string,
  transactions: MealTransaction[],
  dailyReference: number = 288
): DaySummary[] {
  const totalDays = Math.max(1, Math.min(366, diffCalendarDays(startDate, endDate) + 1));
  const byDate = new Map<string, MealTransaction[]>();

  for (const t of transactions) {
    const list = byDate.get(t.date) || [];
    list.push(t);
    byDate.set(t.date, list);
  }

  const summaries: DaySummary[] = [];
  for (let i = 0; i < totalDays; i++) {
    const date = addDaysToDateString(startDate, i);
    const dayTx = (byDate.get(date) || []).sort(
      (a, b) => a.time.localeCompare(b.time) || a.createdAt - b.createdAt
    );
    const totalCredits = roundCredits(dayTx.reduce((s, t) => s + t.credits, 0));
    summaries.push({
      date,
      totalCredits,
      mealCount: dayTx.length,
      status: getDaySpendingStatus(totalCredits, dayTx.length, dailyReference),
      transactions: dayTx,
    });
  }

  return summaries;
}

/**
 * Generates real, data-driven Smart Insights strictly from stored transactions and cycle metrics.
 */
export function generateSmartInsights(
  cycle: BillingCycle,
  metrics: CycleMetrics,
  transactions: MealTransaction[],
  todayDateStr: string = toLocalDateString()
): SmartInsight[] {
  const cycleTx = transactions.filter((t) => t.cycleId === cycle.id);
  const insights: SmartInsight[] = [];

  // 1. Remaining credits & days overview insight (always real from current state)
  if (metrics.daysRemaining > 0) {
    insights.push({
      id: 'remaining-overview',
      type: metrics.remainingCredits >= 0 ? 'info' : 'warning',
      title: 'Remaining Cycle Allowance',
      description: `You have ${formatCredits(metrics.remainingCredits)} credits remaining for ${metrics.daysRemaining} day${metrics.daysRemaining === 1 ? '' : 's'} (recommended ${formatCredits(metrics.recommendedDailyAllowance)} credits/day).`,
      metric: `${formatCredits(metrics.recommendedDailyAllowance)} cr/day`,
    });
  } else {
    insights.push({
      id: 'cycle-ended',
      type: metrics.remainingCredits >= 0 ? 'positive' : 'warning',
      title: 'Billing Cycle Completed',
      description:
        metrics.remainingCredits >= 0
          ? `This billing cycle has ended with ${formatCredits(metrics.remainingCredits)} unused credits.`
          : `This billing cycle ended ${formatCredits(Math.abs(metrics.remainingCredits))} credits above budget.`,
      metric: `${formatCredits(metrics.remainingCredits)} cr`,
    });
  }

  if (cycleTx.length === 0) {
    insights.push({
      id: 'no-entries-yet',
      type: 'neutral',
      title: 'No Meals Recorded Yet',
      description: `Record your first meal in this billing cycle to unlock category trends, average meal costs, and pace projections.`,
    });
    return insights;
  }

  // 2. Pace vs Recommended Daily Allowance
  if (metrics.daysRemaining > 0 && metrics.averageDailySpendSoFar > 0) {
    const diff = roundCredits(
      metrics.recommendedDailyAllowance - metrics.averageDailySpendSoFar
    );
    if (diff >= 1) {
      insights.push({
        id: 'pace-comparison',
        type: 'positive',
        title: 'Below Recommended Daily Allowance',
        description: `Your average daily spending (${formatCredits(metrics.averageDailySpendSoFar)} cr) is currently ${formatCredits(diff)} credits below your recommended daily allowance.`,
        metric: `-${formatCredits(diff)} cr/day`,
      });
    } else if (diff <= -1) {
      insights.push({
        id: 'pace-comparison',
        type: 'warning',
        title: 'Above Recommended Daily Allowance',
        description: `Your average daily spending (${formatCredits(metrics.averageDailySpendSoFar)} cr) is currently ${formatCredits(Math.abs(diff))} credits above your recommended daily allowance.`,
        metric: `+${formatCredits(Math.abs(diff))} cr/day`,
      });
    }
  }

  // 3. Projected end-of-cycle balance
  if (metrics.daysRemaining > 0 && metrics.averageDailySpendSoFar > 0) {
    if (metrics.projectedEndBalance >= 0) {
      insights.push({
        id: 'projected-finish',
        type: 'positive',
        title: 'Sustainable Spending Pace',
        description: `At your current spending pace, you are projected to finish the cycle with ${formatCredits(metrics.projectedEndBalance)} credits remaining.`,
        metric: `+${formatCredits(metrics.projectedEndBalance)} cr`,
      });
    } else {
      insights.push({
        id: 'projected-finish',
        type: 'warning',
        title: 'Projected Budget Overrun',
        description: `At your current spending pace, you may exceed your monthly budget by ${formatCredits(Math.abs(metrics.projectedEndBalance))} credits before cycle end.`,
        metric: `${formatCredits(metrics.projectedEndBalance)} cr`,
      });
    }
  }

  // 4. Average category cost (e.g., Dinner or Lunch or highest frequency meal)
  const categoryStats = MEAL_CATEGORIES.map((category) => {
    const items = cycleTx.filter((t) => t.category === category);
    const sum = roundCredits(items.reduce((s, t) => s + t.credits, 0));
    const avg = items.length > 0 ? roundCredits(sum / items.length) : 0;
    return { category, count: items.length, sum, avg };
  }).filter((c) => c.count > 0);

  const dinnerStat = categoryStats.find((c) => c.category === 'Dinner');
  const topCat = [...categoryStats].sort((a, b) => b.sum - a.sum)[0];

  if (dinnerStat && dinnerStat.count > 0) {
    insights.push({
      id: 'avg-dinner-cost',
      type: 'neutral',
      title: 'Average Dinner Cost',
      description: `Your average dinner cost is ${formatCredits(dinnerStat.avg)} credits across ${dinnerStat.count} recorded dinner${dinnerStat.count === 1 ? '' : 's'}.`,
      metric: `${formatCredits(dinnerStat.avg)} cr`,
    });
  } else if (topCat) {
    insights.push({
      id: 'avg-top-category-cost',
      type: 'neutral',
      title: `Average ${topCat.category} Cost`,
      description: `Your average ${topCat.category.toLowerCase()} cost is ${formatCredits(topCat.avg)} credits (${formatCredits(topCat.sum)} credits total).`,
      metric: `${formatCredits(topCat.avg)} cr`,
    });
  }

  // 5. Week-over-week or recent category comparison (e.g. Snacks or top changing category)
  const sevenDaysAgo = addDaysToDateString(todayDateStr, -6);
  const fourteenDaysAgo = addDaysToDateString(todayDateStr, -13);
  const prevWeekEnd = addDaysToDateString(todayDateStr, -7);

  const thisWeekTx = cycleTx.filter((t) => t.date >= sevenDaysAgo && t.date <= todayDateStr);
  const prevWeekTx = cycleTx.filter((t) => t.date >= fourteenDaysAgo && t.date <= prevWeekEnd);

  if (thisWeekTx.length > 0 && prevWeekTx.length > 0) {
    for (const cat of ['Snacks', 'Dinner', 'Lunch', 'Breakfast'] as MealCategory[]) {
      const thisSum = roundCredits(
        thisWeekTx.filter((t) => t.category === cat).reduce((s, t) => s + t.credits, 0)
      );
      const prevSum = roundCredits(
        prevWeekTx.filter((t) => t.category === cat).reduce((s, t) => s + t.credits, 0)
      );
      if (prevSum > 0 && thisSum !== prevSum) {
        const pctChange = Math.round(((thisSum - prevSum) / prevSum) * 100);
        if (Math.abs(pctChange) >= 5) {
          insights.push({
            id: `wow-${cat.toLowerCase()}`,
            type: pctChange > 0 ? 'warning' : 'positive',
            title: `${cat} Spending Trend`,
            description: `You spent ${Math.abs(pctChange)}% ${pctChange > 0 ? 'more' : 'fewer'} credits on ${cat.toLowerCase()} over the last 7 days (${formatCredits(thisSum)} cr vs ${formatCredits(prevSum)} cr previously).`,
            metric: `${pctChange > 0 ? '+' : ''}${pctChange}%`,
          });
          break;
        }
      }
    }
  } else if (topCat && metrics.totalUsed > 0) {
    const sharePct = Math.round((topCat.sum / metrics.totalUsed) * 100);
    insights.push({
      id: 'top-category-share',
      type: 'info',
      title: `Highest Category: ${topCat.category}`,
      description: `${topCat.category} accounts for ${sharePct}% of your total mess credits spent this cycle (${formatCredits(topCat.sum)} of ${formatCredits(metrics.totalUsed)} credits).`,
      metric: `${sharePct}% share`,
    });
  }

  return insights;
}
