import test from 'node:test';
import assert from 'node:assert/strict';
import {
  roundCredits,
  calculateCycleEndDate,
  calculateCycleDayCounts,
  calculateRecommendedAllowance,
  calculateCycleMetrics,
  calculateTodayBreakdown,
  calculateScenarioProjections,
  getDaySpendingStatus,
  generateSmartInsights,
  isValidCreditAmount,
} from './calculations';
import { BillingCycle, MealTransaction } from '../types/mess';

const createTestCycle = (overrides?: Partial<BillingCycle>): BillingCycle => ({
  id: 'cycle-1',
  name: 'November 2026 Cycle',
  dailyReference: 288,
  cycleDuration: 30,
  monthlyBudget: 8640,
  startDate: '2026-11-01',
  endDate: '2026-11-30',
  isArchived: false,
  createdAt: 1700000000000,
  ...overrides,
});

const createTx = (
  id: string,
  credits: number,
  date: string = '2026-11-01',
  category: MealTransaction['category'] = 'Lunch'
): MealTransaction => ({
  id,
  cycleId: 'cycle-1',
  category,
  foodName: `Item ${id}`,
  credits,
  quantity: 1,
  date,
  time: '12:30',
  createdAt: 1700000000000,
  updatedAt: 1700000000000,
});

test('TEST 1: Monthly budget 8640, transactions 350 + 250 + 300 -> used 900, remaining 7740', () => {
  const cycle = createTestCycle();
  const txs = [
    createTx('1', 350, '2026-11-01'),
    createTx('2', 250, '2026-11-02'),
    createTx('3', 300, '2026-11-03'),
  ];
  const metrics = calculateCycleMetrics(cycle, txs, '2026-11-04');
  assert.equal(metrics.totalUsed, 900);
  assert.equal(metrics.remainingCredits, 7740);
});

test('TEST 2: Remaining credits = 7740, Remaining days = 27 -> Expected daily allowance = 286.67', () => {
  const cycle = createTestCycle();
  const txs = [
    createTx('1', 350, '2026-11-01'),
    createTx('2', 250, '2026-11-02'),
    createTx('3', 300, '2026-11-03'),
  ];
  // On 2026-11-04 (3 days elapsed since Nov 1, 27 days remaining)
  const metrics = calculateCycleMetrics(cycle, txs, '2026-11-04');
  assert.equal(metrics.daysElapsed, 3);
  assert.equal(metrics.daysRemaining, 27);
  assert.equal(metrics.recommendedDailyAllowance, 286.67);
});

test('TEST 3, 4, 5: Add 100-credit meal, edit to 150, delete meal', () => {
  const cycle = createTestCycle();
  let txs = [
    createTx('1', 350, '2026-11-01'),
    createTx('2', 250, '2026-11-02'),
    createTx('3', 300, '2026-11-03'),
  ];

  // TEST 3: Add a 100-credit meal -> Remaining decreases by 100 (from 7740 to 7640)
  txs = [...txs, createTx('4', 100, '2026-11-04')];
  let metrics = calculateCycleMetrics(cycle, txs, '2026-11-04');
  assert.equal(metrics.totalUsed, 1000);
  assert.equal(metrics.remainingCredits, 7640);

  // TEST 4: Edit that meal from 100 to 150 -> Remaining decreases by another 50 (to 7590)
  txs = txs.map((t) => (t.id === '4' ? { ...t, credits: 150 } : t));
  metrics = calculateCycleMetrics(cycle, txs, '2026-11-04');
  assert.equal(metrics.totalUsed, 1050);
  assert.equal(metrics.remainingCredits, 7590);

  // TEST 5: Delete that meal -> Remaining increases by 150 (back to 7740)
  txs = txs.filter((t) => t.id !== '4');
  metrics = calculateCycleMetrics(cycle, txs, '2026-11-04');
  assert.equal(metrics.totalUsed, 900);
  assert.equal(metrics.remainingCredits, 7740);
});

test('TEST 6: Record 500 credits in a single day without restriction & verify Today difference', () => {
  const cycle = createTestCycle();
  const txs = [
    createTx('1', 220, '2026-11-01', 'Lunch'),
    createTx('2', 280, '2026-11-01', 'Dinner'),
  ];
  const today = calculateTodayBreakdown(txs, 288, '2026-11-01', cycle.id);
  assert.equal(today.totalSpent, 500);
  assert.equal(today.differenceFromReference, 212); // 500 - 288 = +212
  assert.equal(today.byCategory.Lunch, 220);
  assert.equal(today.byCategory.Dinner, 280);
});

test('Section 2B & Section 5 Examples match exact formula', () => {
  // Example 2B: Monthly budget 8640, Used 1200, Remaining 7440, Days remaining 25 -> 297.6
  assert.equal(calculateRecommendedAllowance(7440, 25), 297.6);

  // Example 5: Monthly allocation 8640, Used 2000, Remaining 6640, Days remaining 20 -> 332
  assert.equal(calculateRecommendedAllowance(6640, 20), 332);
});

test('Zero remaining days and future cycle dates are handled safely without divide-by-zero', () => {
  const cycle = createTestCycle();
  const txs = [createTx('1', 1200, '2026-11-05')];

  // Completed cycle (Dec 5 > Nov 30)
  const endedMetrics = calculateCycleMetrics(cycle, txs, '2026-12-05');
  assert.equal(endedMetrics.daysRemaining, 0);
  assert.equal(endedMetrics.isCycleEnded, true);
  assert.equal(endedMetrics.recommendedDailyAllowance, 0);

  // Future cycle (Oct 25 < Nov 1) -> 0 elapsed days, 30 remaining days
  const futureMetrics = calculateCycleMetrics(cycle, [], '2026-10-25');
  assert.equal(futureMetrics.daysElapsed, 0);
  assert.equal(futureMetrics.daysRemaining, 30);
  assert.equal(futureMetrics.isCycleFuture, true);
  assert.equal(futureMetrics.recommendedDailyAllowance, 288);
});

test('Floating-point precision is preserved for decimal credit entries', () => {
  const cycle = createTestCycle();
  const txs = [
    createTx('1', 75.1, '2026-11-01'),
    createTx('2', 110.2, '2026-11-01'),
  ];
  const metrics = calculateCycleMetrics(cycle, txs, '2026-11-01');
  assert.equal(metrics.totalUsed, 185.3);
  assert.equal(metrics.remainingCredits, 8454.7);
  assert.equal(roundCredits(0.1 + 0.2), 0.3);
});

test('Scenario projections A, B, C and Custom compute accurate end balances', () => {
  const cycle = createTestCycle();
  const txs = [createTx('1', 2000, '2026-11-05')];
  // Nov 11 -> 10 days elapsed, 20 days remaining, 6640 remaining, 332 recommended
  const metrics = calculateCycleMetrics(cycle, txs, '2026-11-11');
  const scenarios = calculateScenarioProjections(metrics, 300);

  assert.equal(scenarios.length, 4);
  // Scenario A: 332 * 20 = 6640 -> 0 remaining
  assert.equal(scenarios[0].dailySpend, 332);
  assert.equal(scenarios[0].projectedEndBalance, 0);
  assert.equal(scenarios[0].willExceedBudget, false);

  // Scenario B: 350 * 20 = 7000 -> -360 remaining (exceeds budget)
  assert.equal(scenarios[1].dailySpend, 350);
  assert.equal(scenarios[1].projectedEndBalance, -360);
  assert.equal(scenarios[1].willExceedBudget, true);

  // Scenario C: 250 * 20 = 5000 -> +1640 remaining
  assert.equal(scenarios[2].dailySpend, 250);
  assert.equal(scenarios[2].projectedEndBalance, 1640);
  assert.equal(scenarios[2].willExceedBudget, false);

  // Custom Scenario: 300 * 20 = 6000 -> +640 remaining
  assert.equal(scenarios[3].dailySpend, 300);
  assert.equal(scenarios[3].projectedEndBalance, 640);
});

test('Validation rejects negative or zero credits and cycle isolation preserves history', () => {
  assert.equal(isValidCreditAmount(-10), false);
  assert.equal(isValidCreditAmount(0), false);
  assert.equal(isValidCreditAmount(NaN), false);
  assert.equal(isValidCreditAmount(75.5), true);

  // Cycle end date helper
  assert.equal(calculateCycleEndDate('2026-11-01', 30), '2026-11-30');

  // Day status helper
  assert.equal(getDaySpendingStatus(0, 0, 288), 'no-data');
  assert.equal(getDaySpendingStatus(220, 3, 288), 'below');
  assert.equal(getDaySpendingStatus(288, 3, 288), 'on-reference');
  assert.equal(getDaySpendingStatus(340, 4, 288), 'above');

  // Smart insights return real calculated facts
  const cycle = createTestCycle();
  const txs = [createTx('1', 120, '2026-11-01', 'Dinner')];
  const metrics = calculateCycleMetrics(cycle, txs, '2026-11-02');
  const insights = generateSmartInsights(cycle, metrics, txs, '2026-11-02');
  assert.ok(insights.length >= 2);
  assert.ok(insights.some((i) => i.id === 'avg-dinner-cost'));
});
