# Build VIT MessMate APK without installing Android Studio

This project is configured to build a debug APK using GitHub Actions. The Android SDK and Java are installed on the GitHub runner, not on your laptop.

## 1. Upload the project to GitHub
1. Sign in to GitHub and create a new repository named `vit-messmate`.
2. Extract this ZIP on your laptop.
3. Upload the extracted project files and folders to the repository root (not the ZIP file itself).
4. Make sure `.github/workflows/build-android-apk.yml` is included. GitHub may hide dot-folders in some file pickers; enable hidden files if needed.
5. Commit the files to the `main` branch.

## 2. Run the build
1. Open the repository on GitHub.
2. Select **Actions**.
3. Select **Build VIT MessMate Android APK**.
4. If it has not started automatically, choose **Run workflow** → **Run workflow**.
5. Wait for the workflow to finish. A green check means the build succeeded.

## 3. Download the APK
1. Open the completed workflow run.
2. Scroll to **Artifacts**.
3. Download `VIT-MessMate-debug-APK`.
4. Extract the downloaded artifact ZIP; it contains `app-debug.apk`.
5. Transfer `app-debug.apk` to your Android phone and install it. Android may ask you to allow installation from that file manager/browser. Only install APKs you built or trust.

## Important
- This workflow creates a **debug APK** for personal testing. It is not a signed Play Store release.
- The current app's web build is packaged inside an Android WebView; the existing React/TypeScript code is retained.
- Test all app functions on the phone, especially offline behaviour and saved meal/credit data.
- Do not add API keys, passwords, or other secrets to the GitHub repository.
- If the GitHub Actions build fails, open the failed step and share its error log so it can be fixed.
