import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.vit.messmate',
  appName: 'VIT MessMate',
  webDir: 'dist',
};

export default config;
